<?php
include_once 'includes/header.php';
?>

<!-- navbar  -->

<!-- inner banner  -->

<div class="container-fluid inner-banner" style="background-image: url('assets/images/warranty-banner.png');"></div>

<!-- inner banner  -->

<!-- project -->
<div class="container-fluid top-project py-5">
    <div class="maintenace">
        <div class="row">
            <div class="col-lg-3 col-md-4 col-sm-6 my-1 border border-secondary">
                <img src="assets/images/warranty1.png" class="w-100" alt="">
                <h5 class="mt-3 text-center fw-bold">ONE YEAR COMPONENT LIMITED WARRANTY</h5>
                <p class="text-center">Manufacturer coverage, bungee cords-Stainless fittings mounts and hardware</p>
            </div>
            <div class="col-lg-3 col-md-4 col-sm-6 my-1 border border-secondary">
                <img src="assets/images/warranty5.png" class="w-100" alt="">
                <h5 class="mt-3 text-center fw-bold">FIVE YEAR COVER LIMITED WARRANTY</h5>
                <p class="text-center">Manufacturer coverage, of Vinyl or canvas Cover</p>
            </div>
            <div class="col-lg-3 col-md-4 col-sm-6 my-1 border border-secondary">
                <img src="assets/images/warranty10.png" class="w-100" alt="">
                <h5 class="mt-3 text-center fw-bold">TEN YEAR STRUCTURAL LIMITED WARRANTY</h5>
                <p class="text-center">Manufacturer coverage, aluminum frame.</p>
            </div>
            <div class="col-lg-3 col-md-4 col-sm-6 my-1 border border-secondary">
                <img src="assets/images/warrantyall.png" class="w-100" alt="">
                <h5 class="mt-3 text-center fw-bold">LIFETIME STRUCTURAL LIMITED WARRANTY</h5>
                <p class="text-center">Manufacturer coverage, aluminum frame.</p>
            </div>
        </div>
        <div class="row">
            <h3 class="title-2">PEACE OF MIND</h3>
            <p class="para">Our Manufacturers make products that stand the test of time. But even more important, we stand by our products long after the sale. Each product comes with its own unique Manufacturer Limited Warranty that gives you confidence in your purchase. If something happens and you need a warranty replacement along the way, We make that process as quick, easy and convenient as possible. Check out our complete warranty information below. If you have any questions, feel free to contact us or the manufacturer direct for more information.</p>

            <h4 class="title-3">MANUFACTURER LIMITED WARRANTY</h4>
            <div class="my-4">
                <p class="para"><strong>Canopy Covers</strong> (5 Year Limited) – Covers are warranted against cracks, breakage, leaks, and deterioration caused by defects in material and manufacturing workmanship for a period of five (5 years) from the date of purchase. All Canopy covers must be taken down in extreme weather expected to reach 70 mph winds and over</p>
                <p class="para"><strong>Canopy Frames </strong>(10 Year Limited) – Frames are warranted against cracks, breakage, Rust, and ultraviolet deterioration caused by defects in material and manufacturing workmanship for a period of ten (10 years) from the date of purchase. All Frames are engineered to withstand 180 mph winds</p>
                <p class="para"><strong>Canopy Frames </strong>(Lifetime Limited) – Frames are warranted against cracks, breakage, Rust, and ultraviolet deterioration caused by defects in material and manufacturing workmanship for a period of ten (10 years) from the date of purchase. All Frames are engineered to withstand 180 mph winds.</p>
                <p class="para"><strong>Hardware and Accessories</strong> (1 Year) – Hardware and accessories are warranted against defects in material and manufacturing workmanship for a period of one (1) year from the date of purchase.</p>
            </div>
        </div>

        <div class="row  maintenace-services1 text-center">
            <div class="col-md-6 ">
                <p class="border p-1 "><strong>MANUFACTURER LIMITED WARRANTY</strong></p>
                <ol class="border list-unstyled">
                    <li class="my-1">Waterway</li>
                    <li class="my-1">WagnerWerx</li>
                    <li class="my-1">Coastline</li>
                    <li class="my-1">All Canopy Covers</li>
                    <li class="my-1">Dock Anchoring</li>
                    <li class="my-1">Dock Connection Kits</li>
                    <li class="my-1">Dock Accessories</li>
                    <li class="my-1">PWC Port Accessories</li>

                </ol>
            </div>
            <div class="col-md-6">
                <p class="border p-1"><strong>WARRANTY PERIOD</strong></p>

                <ol class="border list-unstyled">
                    <li class="my-1">Lifetime</li>
                    <li class="my-1">Lifetime</li>
                    <li class="my-1">10 Years</li>
                    <li class="my-1">5 Years</li>
                    <li class="my-1">1 Years</li>
                    <li class="my-1">1 Years</li>
                    <li class="my-1">1 Years</li>
                    <li class="my-1">1 Years</li>
                </ol>
            </div>
        </div>

        <p class="para">These Limited Warranties specifically do not cover damages to Canopy products caused by improper installation; use inconsistent with Canopy Manufacturer instructions and product specifications; vandalism; severe weather and natural disaster; impact by watercraft, ice, falling trees, floating debris, and other foreign objects; animals or aquatic life; unauthorized product modification and attachment; and improper repair.</p>
        <p class="para">If a Manufacturer product fails under normal use and within the applicable warranty period, Buyer must submit a written claim to Manufacturer who’s address is stated on the Warranty information provided at the point of sale or installation. Claims must be submitted with pictures and in writing and identify the failed product(s), describe the claimed defect(s), and include copies of dated proofs of purchase/receipts from an authorized reseller and installer such as Transformation Marine.</p>
        <p class="para">Upon receiving sufficient proof of covered product failure, Manufacturer will, in its sole discretion, either repair or replace failed products within a reasonable time after notice, and ship, at Buyer’s expense, repaired and/or replacement products to the site. “Repair” may be limited to providing a repair kit to Buyer. Costs related to the removal of failed products, and the installation of repaired and/or replaced products shall be at the Buyer’s expense. Warranty periods begin on the date of purchase from an authorized reseller such as Transformation Marine. Repaired and replacement products are warranted only for the balance of the original limited warranty period. These limited warranties extend only to the original Buyer of products from an authorized manufacturer reseller (“Original Purchaser”). Warranties are not transferable to anyone who subsequently purchases products from the Original Purchaser, or to any subsequent purchaser.</p>
        <p class="para">In order to ensure proper warranty coverage, Buyer should activate these Limited Warranties by properly registering the purchase of the Manufacturer products within thirty (30) days of the date of purchase via the Registration Card provided in your Owner’s Manual and or Paperwork, or by registering online by going to manufacturer website. The buyer, by acceptance and use of these limited warranties, waives any rights it would otherwise have to claim or assert that these limited warranties fail their essential purposes. The buyer agrees that the venue for any court action to enforce these limited warranties shall be the State of the Manufacturer.</p>
        <p class="para">THE FOREGOING 1 YEAR, 5 YEAR, 10 YEAR and or LIFETIME LIMITED WARRANTY IS THE SOLE AND EXCLUSIVE WARRANTY FOR SELLER’S PRODUCTS, AND IS IN LIEU OF ALL OTHER WARRANTIES, EXPRESS OR IMPLIED, IN LAW OR IN FACT. SELLER SPECIFICALLY DISCLAIMS ALL OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING, WITHOUT LIMITATION, ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR USE OR PURPOSE, AND ANY IMPLIED WARRANTIES ARISING OUT OF COURSE OF DEALING OR PERFORMANCE OR TRADE USAGE. SELLER SHALL NOT BE LIABLE FOR ANY INCIDENTAL, CONSEQUENTIAL, EXEMPLARY, SPECIAL, OR PUNITIVE DAMAGES, OR ANY LOSS OF REVENUE, PROFIT OR USE, ARISING OUT OF A BREACH OF THIS WARRANTY OR IN CONNECTION WITH THE SALE, INSTALLATION, MAINTENANCE, USE, OPERATION OR REPAIR OF ANY PRODUCT. IN NO EVENT WILL THE SELLER BE LIABLE FOR ANY AMOUNT GREATER THAN THE PURCHASE PRICE OF A DEFECTIVE PRODUCT.</p>
        <p class="para text-decoration-underline">DOWNLOAD A COPY</p>
        <p class="para">Do you have feedback on your experience with Transformation Marine and our products so far? We would be grateful if you took a moment to share!</p>
        <p class="para text-decoration-underline">GIVE FEEDBACK </p>

        <h3 class="title-2 text-center">HURRICANE PROTOCOL</h3>
        <p class="para">Dear Customers,</p>
        <p class="para">The most important thing to remember is that the top cover MUST be removed from the frame if winds are expected to exceed 70 MPH in a storm. Otherwise, the Warranty is Voided. No cover warranty can protect from Hurricane, Natural disaster and or acts of God. That being said we offer removal service to the first 100 customers that sign up.</p>
        <p class="para">Hurricanes are unpredictable they can change direction, fall apart, or increase at any time. Unfortunately, we will not be able to make the determination to remove your canopy for you.</p>
        <p class="para">If you choose to remove your canopy yourself – Start in the middle and accordion fold from the back to the middle then from the front to the middle. After it is folded roll it up from the offshore side (the side furthest from the seawall).</p>
        <p class="para ">FOR REMOVAL SERVICE EMAIL US AT <a href="mailto:transformationmarine@gmail.com" class="text-decoration-none" style="color: #c36 !important;">transformationmarine@gmail.com</a></p>
        <p class="para">Send your name, address, and phone number.</p>
        <p class="para">Removal is not guaranteed but we will try to get to as many clients as possible that are on the pre registered list.</p>
        <p class="para">Transformation Marine will work diligently to get as many covers removed as possible but cannot guarantee to get all the tops removed. Our technicians will be out removing covers as long as it is safe, we have access to gas and our employees are not in a mandatory evacuation order.</p>
        <p class="para">Following a Major Storm or Named Hurricane, send an additional email with your contact information for reinstallation. For any Frame damage send all contact info and send pictures please, this will help us better decipher if we can repair or need to replace.</p>
        <p class="para">The removals will start when a named hurricane appears to be coming our way.</p>
        <p class="para">We DO NOT require a deposit to get on the removal list. </p>
        <p class="para">Pricing for Removal is $250.00 and then Reinstall is $275.00 w/New Bungees add $88.00 If you do not remove the cover and need a replacement after the storm, Email us with all your contact info and your new color choice. All replacements will be made available at normal replacement cost including Install</p>

    </div>
</div>
<!-- project -->


<!-- footer  -->
<?php 
include_once 'includes/footer.php';
?>

<!-- footer  -->

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
<!-- Lightbox JavaScript -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/js/lightbox.min.js"></script>

<script src="assets/js/script.js"></script>

</body>

</html>
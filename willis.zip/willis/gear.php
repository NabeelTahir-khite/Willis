<?php
include_once 'includes/header.php';
?>

<!-- navbar  -->

<!-- inner banner  -->

<div class="container-fluid inner-banner" style="background-image: url('assets/images/gear-banner.jpg');"></div>

<!-- inner banner  -->

<!-- about  -->
<div class="container about p-5">
    <div class="row">
        <div class="col-lg-4 my-3 d-flex justify-content-center align-items-center px-lg-5">
            <img src="assets/images/gear-about.png" class="w-75 rounded" height="300" alt="">
        </div>
        <div class="col-lg-4 my-3 px-lg-5">

            <div class="my-4">
                <p class="para1">Ask about a TM GEAR free Hat or Shirt with your Purchase
                </p>
                <h3 class="title-2">Create Your Design</h3>
                <p class="para1">Our in-house design team is at your disposal to help bring your vision to life. We’ve learned that being in constant communication results in the best customer experience. We’ve created custom artwork for boats, (mega)yachts, event artwork, business logos and more.
                </p>

            </div>
        </div>

        <div class="col-lg-4 my-3 d-flex justify-content-center align-items-center px-lg-5">
            <img src="assets/images/gear-about1.png" class="w-75 rounded" height="300" alt="">
        </div>
    
      
    </div>

</div>
<!-- about  -->


<!-- project -->
<!-- <div class="container-fluid top-project py-5">

    <div class="row justify-content-center mt-4">

        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/pwc-port-accessories1.jpg" data-lightbox="gallery">
                    <img src="assets/images/pwc-port-accessories1.jpg" alt="">
                </a>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/pwc-port-accessories2.jpg" data-lightbox="gallery">
                    <img src="assets/images/pwc-port-accessories2.jpg" alt="">
                </a>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/pwc-port-accessories3.jpg" data-lightbox="gallery">
                    <img src="assets/images/pwc-port-accessories3.jpg" alt="">
                </a>
            </div>
        </div>





    </div>

</div> -->
<!-- project -->


<!-- footer  -->
<?php
include_once 'includes/footer.php';
?>

<!-- footer  -->

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
<!-- Lightbox JavaScript -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/js/lightbox.min.js"></script>

<script src="assets/js/script.js"></script>

</body>

</html>
<?php
include_once 'includes/header.php';
?>


<!-- inner banner  -->

<div class="container-fluid inner-banner" style="background-image: url('assets/images/canopy-maintenance-banner.png');"></div>

<!-- inner banner  -->


<!-- about  -->
<div class="container about p-5">
    <div class="row">
        <div class="col-lg-6 my-3 d-flex justify-content-center align-items-center px-lg-5 maintenace-image">
            <img src="assets/images/canopy-maintenance2.gif" class="w-50 h-100 rounded-start" alt="">
            <img src="assets/images/canopy-maintenance3.gif" class="w-50 h-100 rounded-end" alt="">
        </div>
        <div class="col-lg-6 my-3 d-flex flex-column justify-content-center align-items-start px-lg-5">
            <h2 class="short-title"> <img src="assets/images/about-icon.png" class="small-icon-1" alt="">
                SERVICES MAINTENANCE</h2>
            <h3 class="title-3">Maintaining your Canopy Cover can and will help extend the life of your investment</h3>

            <div class="my-4">
                <p class="para2">While our covers are waterproof, flame, mildew, stain, and dirt resistant, it is important to practice routine maintenance and cleaning to keep your canopy cover performing to its max. </p>


            </div>
        </div>

    </div>
</div>
<!-- about  -->


<!-- project -->
<div class="container-fluid project py-5">
    <div class="maintenace">
        <div class="row text-center">

            <h3 class="title-2 text-white">MAINTENANCE AND BUNGEE REPLACEMENTS</h3>

            <h4 class="title-3 text-white">KEEP YOUR CANOPY SECURE THIS SEASON</h4>
            <div class="my-4">
                <p class="para1 text-white">Sun, salt, and water are all natural causes of wear and tear to the bungee cords, reducing their ability to hold your canopy firmly on the structure during high winds. We highly recommend changing your bungee cords every (3) years to keep your canopy safe in seasonal high winds. </p>
                <p class="para1 text-white mt-3">We also offer cleaning and maintenance agreements along with bungee replacement service for those that want turnkey service.</p>
            </div>
        </div>


    </div>

    <div class="row justify-content-center mt-4">
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/canopy-maintenance1.jpg" data-lightbox="gallery">
                    <img src="assets/images/canopy-maintenance1.jpg" alt="">
                </a>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/canopy-maintenance2.gif" data-lightbox="gallery">
                    <img src="assets/images/canopy-maintenance2.gif" alt="">
                </a>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/canopy-maintenance3.gif" data-lightbox="gallery">
                    <img src="assets/images/canopy-maintenance3.gif" alt="">
                </a>
            </div>
        </div>


    </div>

</div>
<!-- project -->


<!-- footer  -->
<?php 
include_once 'includes/footer.php';
?>

<!-- footer  -->

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
<!-- Lightbox JavaScript -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/js/lightbox.min.js"></script>

<script src="assets/js/script.js"></script>

</body>

</html>
<?php
include_once 'includes/header.php';
?>

<!-- navbar  -->

<!-- inner banner  -->

<div class="container-fluid inner-banner" style="background-image: url('assets/images/marine-banner.png');"></div>

<!-- inner banner  -->

<!-- about  -->
<div class="container about p-5">
    <div class="row ">
        <div class="col-lg-6 my-3 d-flex justify-content-center flex-column px-lg-5">
            <img src="assets/images/marine-about.png" class="w-100 rounded" alt="">
        </div>
        <div class="col-lg-6 my-3 d-flex flex-column justify-content-center align-items-start px-lg-5">
            <h2 class="short-title"> <img src="assets/images/about-icon.png" class="small-icon-1" alt="">
                BENEFITS OF SOLAR PANELS FOR BOATS</h2>

            <div class="my-4">
                <p class="para1">Marine solar panels are perfect for keeping batteries topped off while you’re
                    disconnected from shore power.</p>
                <p class="para1">This means that while you’re out fishing or anchored for the evening, you can run
                    your electronics (TV, laptop, cell phone charger, stereo, cabin lights, navigation lights, bilge
                    pump, GPS, etc.), and still have enough power to start your engine and get home.</p>
                    
                     <p class="para1">You can also safely generate electricity and charge your batteries with solar power while
            you’re away from your boat. This isn’t possible with generators, which require manual operation and
            monitoring. With solar panels on your boat, you can produce usable electricity during the day and then
            use it for weekend boating adventures.</p>

            </div>
        </div>

       

        <p class="para1">One of the most attractive benefits is the money and time you’ll be saving. For a small
            upfront investment, you’ll be generating free electricity for your boat for as long as your panels last.
            Alternatives to powering electronics on your boat, like <a href="https://citimarinestore.com/en/27-marine-generators" target="_blank" style="color: #c36;">marine
                generators</a> , require purchasing fuel on an ongoing basis which is both time-consuming and a
            continuing cost.</p>
        <p class="para1">Another benefit of solar panels for boats is the noiseless operation. For those going out
            on the open water to experience nature, running a generator can be a noisy disturbance. By powering your
            boat with solar, you can enjoy peace and quiet without losing power.</p>

    </div>

    <div class="row ">

        <div class="col-lg-6 my-3 px-lg-5">
            <h2 class="short-title"> <img src="assets/images/about-icon.png" class="small-icon-1" alt="">
                How Solar Panels Bring Electricity Onto Your Boat</h2>

            <h3 class="title-3">A solar power installation consists of two independent systems:
            </h3>

            <div class="my-4">
                <p class="para1"><strong>(1)</strong> to charge the batteries
                    <strong>(2)</strong> to provide 120-volt AC power for household appliances
                    In the charging system <strong>(1)</strong>, the solar panels convert sunlight into electrical
                    current and deliver it to the batteries via a solar charge controller. Similar to a voltage
                    regulator, the charge controller acts as a gatekeeper to protect the batteries from receiving
                    more current than they need as they are being charged.
                    In the AC power system <strong>(2)</strong>, an inverter converts the 12-volt DC power in the
                    battery into 120 volt AC household power whenever it is turned on, allowing it to power
                    appliances.
                    A charge controller is an essential component of your marine solar power system. The controller
                    maintains the life of the battery by protecting it from overcharging. When your battery has
                    reached a 100% state of charge, the controller prevents overcharging by limiting the current
                    flowing into the batteries from your solar panels.
                </p>


            </div>
        </div>
        <div class="col-lg-6 my-3 d-flex justify-content-center flex-column px-lg-5">
            <img src="assets/images/marine-solar.png" class="w-100 rounded" alt="">
        </div>
    </div>
    <div class="row ">
        <div class="col-lg-6 my-3 d-flex justify-content-center flex-column px-lg-5">
            <img src="assets/images/marine-boat.jpg" class="w-100 rounded" alt="">
        </div>
        <div class="col-lg-6 my-3 px-lg-5">


            <h3 class="title-3">How Many Solar Panels Will You Need On Your Own Boat? </h3>

            <div class="my-4">
                <p class="para1">The first step when figuring out how many panels you need is to figure out your
                    boat’s power requirements. Creating an excel or google sheet, or using this sheet, is the best
                    way to organize this.
                </p>
                <p class="para1">Add up all the energy used by each device on your boat, such as the fridge, lights,
                    computers, etc. by checking the badge on the appliance to give you the power requirements in
                    watts or amps. You will want to use either all watts or amps when making your computations, and
                    match it to the solar panel’s quoted output. <a href="https://www.inchcalculator.com/watts-to-amps-calculator/" style="color: #c36;" target="_blank"> This online calculator</a> can help you convert watts to amps and vice
                    versa for when needed.
                </p>


            </div>
        </div>

        <p class="para1"><strong>Note:</strong> Just for your reference, the relationship between power and current
            is expressed as: Power (W) = Current (A) x System Voltage (V)
            Next you want to calculate all of the watt-hours or amp-hours of each device – get the watt or amp
            output of each device and then multiply it by the hours per day the appliance will be running.
        </p>
        <p class="para1">When making estimates, take into account that some appliances will work harder during
            certain hours – for instance, the fridge will work harder when the sun is out and the temperature rises,
            or you will use your <a href="https://citimarinestore.com/en/19-marine-watermakers-for-sale" style="color: #c36;" target="_blank">watermaker</a>  more should there be more guests onboard.
        </p>
        <p class="para1">You will also need to calculate how much power you can reasonably expect to get from your
            panels over 24 hours, and ensure that the panels are powerful enough to supply your complete power
            requirements in the daytime, plus have enough capacity to charge the battery by the amount it has been
            depleted overnight.
        </p>
        <p class="para1">Once you’ve figured out your energy requirements, you should add at least an extra 10%
            margin for expansion and errors. Underestimate your power needs and you will end up having to run the
            engine to top off the batteries every so often.
        </p>
        <p class="para1">Worse comes to worst, you can always add another panel or two later. Power usage
            fluctuates, and is hard to predict. After cruising, you should get a better idea. And keep in mind – a
            bit more is always better than a bit less.
        </p>
    </div>

    <div class="row ">

        <div class="col-lg-6 my-3 px-lg-5">


            <h3 class="title-3">How Much Power Can You Reasonably – and Consistently – Expect to Get from Your Solar
                Panels While Out Boating?
            </h3>

            <div class="my-4">
                <p class="para1">You may be wondering if you’ll get the quoted wattage from your panel — If the
                    panel is a 100 watt panel, will you really get 100 watts?
                    Panels are rated by the electrical power produced under certain testing conditions, generally
                    the best possible solar and clarity conditions. But do you ever really get these when out
                    boating?
                </p>
                <p class="para1">On the right days, a solar panel will put out its maximum output (when the panel is
                    in the full sun – defined as 1000 watts of energy per square meter) for a set number of “<a href="https://energyeducation.ca/encyclopedia/Insolation" style="color: #c36;" target="_blank">insolation</a>” hours. A good indicator that you are under full sunlight is
                    when there are fairly sharp-edged shadows. In most of the continental US, there is an average of
                    4 or 5 hours of insolation per day. You can get a good estimate of <a href="https://www.nrel.gov/gis/solar.html" style="color: #c36;" target="_blank">your
                        region’s insolation hours, here</a> .
                </p>
                <p class="para1">Even though the sun may be above the horizon 14 hours a day, any one site may only
                    receive a maximum of six hours of full sun hours per day for the following reasons: 1) the
                    reflection due to a high angle of the sun in relationship to your solar panel, and 2) the amount
                    of the earth’s atmosphere the light is passing through. When the sun is straight overhead the
                    light is passing through the least amount of atmosphere. Early or late in the day, the sunlight
                    is passing through much more of the atmosphere due to its position in the sky.
                </p>


            </div>
        </div>
        <div class="col-lg-6 my-3 d-flex justify-content-center flex-column px-lg-5">
            <img src="assets/images/marine-power.jpg" class="w-100 rounded" alt="">
        </div>
    </div>

    <h3 class="title-3">An example to better illustrate solar panel output related to daily hours of sunlight
    </h3>
    <p class="para1">When using appliances, they draw power off your battery. Solar panels put this energy back into
        the battery banks.
        For instance, one Go Power Flex-100 panel will put about 5 amps per hour back into your battery bank. So if
        you are using 20 amps per day, it will take you approximately 4 hours of insolation hitting your panel to
        fully recharge your batteries.
    </p>
    <p class="para1">As to how much power you can expect to get from any individual solar panel per day, let’s say
        you are using the Go Power 100-watt solar panel that produces 5 amps peak power in a location that has 5
        hours of insolation, it can be said that the 100W panel will produce 25 amp hours a day.
        Two Go Power Flex-100’s will provide you with 50 amp hours a day… and so on and so forth.
    </p>

    <div class="row ">
        <div class="col-lg-6 my-3 d-flex justify-content-center flex-column px-lg-5">
            <img src="assets/images/marine-boat-solar.jpg" class="w-100 rounded" alt="">
        </div>
        <div class="col-lg-6 my-3 px-lg-5">

            <h2 class="short-title"> <img src="assets/images/about-icon.png" class="small-icon-1" alt="">
                How to Get the Most out of Your Boat’s Solar Panels</h2>

            <h3 class="title-2">Bear in mind the following tips to maximize the energy your solar panels will produce:
            </h3>
            <div class="my-4">
                <p class="para1"><strong>1) Keep your panels as perpendicular to the incoming sun’s rays as possible:</strong> All panels will produce more power if they get direct sunlight. Mount your panels as best possible so they can be aimed in the appropriate direction, no matter what the season, course, or latitude.
                </p>
                <p class="para1"><strong>2) Consider shadows when placing your panels: </strong>The output of a panel drops dramatically when under a shadow, even if only 10 percent of the panel is covered. A small shadow can reduce the panel’s output by 50 percent or more. When something as large as a boom, radar scanner, or mast casts its shadow on a panel, your output goes down dramatically.
                </p>
                <p class="para1"><strong>3) Keep your panels cool:</strong> It’s not easy to keep a black surface cool in the sun, but panel output can go down as the temperature rises, so if you can provide some ventilation on the backside of the panel, you may be able to pick up a decent increase in energy production. The colder the panel, the higher the output. For instance, a solar panel’s performance on a clear, cold winter day can be 30 to 40 percent over rated specs!
                </p>


            </div>
        </div>

    </div>

</div>
<!-- about  -->

<!-- project -->
<div class="container-fluid project py-5">
    
    <div class="project-title">
        <h2 class="title text-center">“STAY OFF THE GRID BY GENERATING YOUR OWN POWER AND SAVE”</h2>
    </div>


    <div class="row justify-content-center mt-4">

        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/marine1.png" data-lightbox="gallery">
                    <img src="assets/images/marine1.png" alt="">
                </a>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/marine2.jpg" data-lightbox="gallery">
                    <img src="assets/images/marine2.jpg" alt="">
                </a>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/marine3.png" data-lightbox="gallery">
                    <img src="assets/images/marine3.png" alt="">
                </a>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/marine4.png" data-lightbox="gallery">
                    <img src="assets/images/marine4.png" alt="">
                </a>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/marine5.png" data-lightbox="gallery">
                    <img src="assets/images/marine5.png" alt="">
                </a>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/marine6.png" data-lightbox="gallery">
                    <img src="assets/images/marine6.png" alt="">
                </a>
            </div>
        </div>



    </div>

</div>
<!-- project -->


<!-- footer  -->
<?php 
include_once 'includes/footer.php';
?>

<!-- footer  -->

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
<!-- Lightbox JavaScript -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/js/lightbox.min.js"></script>

<script src="assets/js/script.js"></script>

</body>

</html>
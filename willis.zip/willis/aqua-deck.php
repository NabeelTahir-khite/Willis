<?php
include_once 'includes/header.php';
?>

<!-- navbar  -->

<!-- inner banner  -->

<div class="container-fluid inner-banner" style="background-image: url('assets/images/aqua-deck-banner1.png');"></div>

<!-- inner banner  -->

<!-- about  -->
<div class="container about p-5">
    <div class="row">
        <div class="col-lg-6 my-3 d-flex justify-content-center align-items-center px-lg-5">
            <img src="assets/images/aqua-deck-about.jpg" class="w-100 rounded" height="300" alt="">
        </div>
        <div class="col-lg-6 my-3 px-lg-5">

            <h3 class="title-3">Transformation Marine is an authorized Dealer - Installer of Aqua Marine Deck </h3>

            <div class="my-4">
                <p class="para1">Aqua Marine Deck's top grade non-skid resistant, closed cell marine foam products provide an attractive, cost-effective choice for boating and marine vessel needs. Our foam is a non-absorbent, closed cell marine foam and has the option to emboss logos and graphics and include a finished beveled edge. Our texture surface adds to the non-skid traction provided by our products. All of our products are specially made and designed. The Aqua Marine Deck foam products have a pressure sensitive adhesive on a peel-and-stick backing that makes installation fast and easy for anyone to install. Our foam products are stain resistant and easy to keep clean, and they are moisture resistant. Our mats also protect the finishes of the boat to keep your boat looking new longer.</p>

            </div>
        </div>
    </div>
    <div class="row">

        <p class="para1">Aqua Marine Deck non-skid products are especially convenient because it can be customized to fit all parts of your boat. These mats are suitable for any type of marine craft such as commercial marine craft, sports boats, fishing boats, flats bottom boats, sailboats, catamarans, ski boats, house boats, personal water craft, pontoon boats, towboats and more. There are no limits to how Aqua Marine Decks products can be used. Any place on your boat where you would like to add comfort for standing or leaning, or add traction for safety, is a good place for one of our mats.</p>

        <p class="title-3">Examples of spots on your boat suited for our mats include:</p>

        <h4 class="image-title d-flex justify-content-start align-items-center"><span><svg aria-hidden="true" class="circle-icon mx-2" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                    <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                    </path>
                </svg></span> Swim platforms</h4>

        <h4 class="image-title d-flex justify-content-start align-items-center"><span><svg aria-hidden="true" class="circle-icon mx-2" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                    <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                    </path>
                </svg></span> Steps</h4>
        <h4 class="image-title d-flex justify-content-start align-items-center"><span><svg aria-hidden="true" class="circle-icon mx-2" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                    <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                    </path>
                </svg></span> Stations</h4>
        <h4 class="image-title d-flex justify-content-start align-items-center"><span><svg aria-hidden="true" class="circle-icon mx-2" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                    <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                    </path>
                </svg></span> Poling / Casting Platforms</h4>
        <h4 class="image-title d-flex justify-content-start align-items-center"><span><svg aria-hidden="true" class="circle-icon mx-2" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                    <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                    </path>
                </svg></span> Coaming Bolsters</h4>
        <h4 class="image-title d-flex justify-content-start align-items-center"><span><svg aria-hidden="true" class="circle-icon mx-2" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                    <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                    </path>
                </svg></span> Footwells</h4>
        <h4 class="image-title d-flex justify-content-start align-items-center"><span><svg aria-hidden="true" class="circle-icon mx-2" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                    <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                    </path>
                </svg></span> Gunnels</h4>
        <h4 class="image-title d-flex justify-content-start align-items-center"><span><svg aria-hidden="true" class="circle-icon mx-2" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                    <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                    </path>
                </svg></span> Cockpits</h4>
        <h4 class="image-title d-flex justify-content-start align-items-center"><span><svg aria-hidden="true" class="circle-icon mx-2" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                    <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                    </path>
                </svg></span> Trailers</h4>

        <p class="para1 mt-3">Our Aqua Marine Deck products are really quick and easy to install. Our marine foam products are available in a wide selection of sizes, thicknesses and colors so you can customize your mats to fit your boat and your style</p>



        <p class="title-3">Characteristics of our mats include:</p>

        <h4 class="image-title d-flex justify-content-start align-items-center"><span><svg aria-hidden="true" class="circle-icon mx-2" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                    <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                    </path>
                </svg></span> Provide stability and traction, wet or dry</h4>

        <h4 class="image-title d-flex justify-content-start align-items-center"><span><svg aria-hidden="true" class="circle-icon mx-2" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                    <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                    </path>
                </svg></span> Soft foam which provides additional comfort for standing on your boat</h4>

        <h4 class="image-title d-flex justify-content-start align-items-center"><span><svg aria-hidden="true" class="circle-icon mx-2" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                    <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                    </path>
                </svg></span> Reduces stress, absorbs shock</h4>

        <h4 class="image-title d-flex justify-content-start align-items-center"><span><svg aria-hidden="true" class="circle-icon mx-2" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                    <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                    </path>
                </svg></span> Keeps boat surfaces from getting marked or damaged</h4>

        <h4 class="image-title d-flex justify-content-start align-items-center"><span><svg aria-hidden="true" class="circle-icon mx-2" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                    <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                    </path>
                </svg></span> Helps reduce noise</h4>

        <h4 class="image-title d-flex justify-content-start align-items-center"><span><svg aria-hidden="true" class="circle-icon mx-2" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                    <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                    </path>
                </svg></span> Anti-Fungal Resistant</h4>

        <h4 class="image-title d-flex justify-content-start align-items-center"><span><svg aria-hidden="true" class="circle-icon mx-2" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                    <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                    </path>
                </svg></span> Mold & Mildew Resistant</h4>

        <h4 class="image-title d-flex justify-content-start align-items-center"><span><svg aria-hidden="true" class="circle-icon mx-2" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                    <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                    </path>
                </svg></span> UV Resistant</h4>

        <h4 class="image-title d-flex justify-content-start align-items-center"><span><svg aria-hidden="true" class="circle-icon mx-2" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                    <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                    </path>
                </svg></span> UV Protection</h4>


        <p class="title-3">We offer:</p>

        <h4 class="image-title d-flex justify-content-start align-items-center"><span><svg aria-hidden="true" class="circle-icon mx-2" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                    <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                    </path>
                </svg></span> Bevels, contours, logos or graphics customized for your needs</h4>

        <h4 class="image-title d-flex justify-content-start align-items-center"><span><svg aria-hidden="true" class="circle-icon mx-2" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                    <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                    </path>
                </svg></span> Multi-color laminations</h4>


    </div>

    <div class="row">
        <h3 class="title-2 text-center">Available Colors</h3>
        <p class="para1 text-center">Depending on your monitor color setting, colors may vary in person.</p>

        <div class="row justify-content-center">

            <div class="col-lg-3 col-md-4 col-sm-6 my-2">
                <div class="card p-3">
                    <img class="card-img-top" src="assets/images/aqua-deck-color1.png" alt="Card image">
                    <div class="card-body py-0">
                        <h4 class="card-title text-center mt-3">Bahama Blue on Medium Gray</h4>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-4 col-sm-6 my-2">
                <div class="card p-3">
                    <img class="card-img-top" src="assets/images/aqua-deck-color2.png" alt="Card image">
                    <div class="card-body py-0">
                        <h4 class="card-title text-center mt-3">Beachsand on Beige</h4>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-4 col-sm-6 my-2">
                <div class="card p-3">
                    <img class="card-img-top" src="assets/images/aqua-deck-color3.png" alt="Card image">
                    <div class="card-body py-0">
                        <h4 class="card-title text-center mt-3">Beachsand on Brown</h4>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-4 col-sm-6 my-2">
                <div class="card p-3">
                    <img class="card-img-top" src="assets/images/aqua-deck-color4.png" alt="Card image">
                    <div class="card-body py-0">
                        <h4 class="card-title text-center mt-3">Beige on Beachsand</h4>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-4 col-sm-6 my-2">
                <div class="card p-3">
                    <img class="card-img-top" src="assets/images/aqua-deck-color5.png" alt="Card image">
                    <div class="card-body py-0">
                        <h4 class="card-title text-center mt-3">Beige on Black</h4>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-4 col-sm-6 my-2">
                <div class="card p-3">
                    <img class="card-img-top" src="assets/images/aqua-deck-color6.png" alt="Card image">
                    <div class="card-body py-0">
                        <h4 class="card-title text-center mt-3">Bimini Blue on Black</h4>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-4 col-sm-6 my-2">
                <div class="card p-3">
                    <img class="card-img-top" src="assets/images/aqua-deck-color7.png" alt="Card image">
                    <div class="card-body py-0">
                        <h4 class="card-title text-center mt-3">Bimini Blue on Medium Gray</h4>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-4 col-sm-6 my-2">
                <div class="card p-3">
                    <img class="card-img-top" src="assets/images/aqua-deck-color8.png" alt="Card image">
                    <div class="card-body py-0">
                        <h4 class="card-title text-center mt-3">Black on Beige</h4>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-4 col-sm-6 my-2">
                <div class="card p-3">
                    <img class="card-img-top" src="assets/images/aqua-deck-color9.png" alt="Card image">
                    <div class="card-body py-0">
                        <h4 class="card-title text-center mt-3">Black on Bimini Blue</h4>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-4 col-sm-6 my-2">
                <div class="card p-3">
                    <img class="card-img-top" src="assets/images/aqua-deck-color10.png" alt="Card image">
                    <div class="card-body py-0">
                        <h4 class="card-title text-center mt-3">Black on Brown</h4>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-4 col-sm-6 my-2">
                <div class="card p-3">
                    <img class="card-img-top" src="assets/images/aqua-deck-color11.png" alt="Card image">
                    <div class="card-body py-0">
                        <h4 class="card-title text-center mt-3">Black on Medium Gray</h4>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-4 col-sm-6 my-2">
                <div class="card p-3">
                    <img class="card-img-top" src="assets/images/aqua-deck-color12.png" alt="Card image">
                    <div class="card-body py-0">
                        <h4 class="card-title text-center mt-3">Black on Storm Gray</h4>
                    </div>
                </div>
            </div>

        </div>

    </div>
</div>
<!-- about  -->

<!-- project -->
<div class="container-fluid project py-5">

    <h2 class="title text-center">Just a few of our projects to Inspire You</h2>


    <div class="row justify-content-center mt-4">

        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/aqua-deck1.jpg" data-lightbox="gallery">
                    <img src="assets/images/aqua-deck1.jpg" alt="">
                </a>
            </div>
        </div>

        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/aqua-deck2.jpg" data-lightbox="gallery">
                    <img src="assets/images/aqua-deck2.jpg" alt="">
                </a>
            </div>
        </div>

        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/aqua-deck3.jpg" data-lightbox="gallery">
                    <img src="assets/images/aqua-deck3.jpg" alt="">
                </a>
            </div>
        </div>

        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/aqua-deck4.png" data-lightbox="gallery">
                    <img src="assets/images/aqua-deck4.png" alt="">
                </a>
            </div>
        </div>

        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/aqua-deck5.png" data-lightbox="gallery">
                    <img src="assets/images/aqua-deck5.png" alt="">
                </a>
            </div>
        </div>

        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/aqua-deck5.png" data-lightbox="gallery">
                    <img src="assets/images/aqua-deck5.png" alt="">
                </a>
            </div>
        </div>

        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/aqua-deck6.jpg" data-lightbox="gallery">
                    <img src="assets/images/aqua-deck6.jpg" alt="">
                </a>
            </div>
        </div>

        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/aqua-deck7.jpg" data-lightbox="gallery">
                    <img src="assets/images/aqua-deck7.jpg" alt="">
                </a>
            </div>
        </div>

        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/aqua-deck8.jpg" data-lightbox="gallery">
                    <img src="assets/images/aqua-deck8.jpg" alt="">
                </a>
            </div>
        </div>

        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/aqua-deck9.jpg" data-lightbox="gallery">
                    <img src="assets/images/aqua-deck9.jpg" alt="">
                </a>
            </div>
        </div>

        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/aqua-deck10.jpg" data-lightbox="gallery">
                    <img src="assets/images/aqua-deck10.jpg" alt="">
                </a>
            </div>
        </div>

        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/aqua-deck11.jpg" data-lightbox="gallery">
                    <img src="assets/images/aqua-deck11.jpg" alt="">
                </a>
            </div>
        </div>

        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/aqua-deck12.jpg" data-lightbox="gallery">
                    <img src="assets/images/aqua-deck12.jpg" alt="">
                </a>
            </div>
        </div>

        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/aqua-deck13.jpg" data-lightbox="gallery">
                    <img src="assets/images/aqua-deck13.jpg" alt="">
                </a>
            </div>
        </div>

        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/aqua-deck14.png" data-lightbox="gallery">
                    <img src="assets/images/aqua-deck14.png" alt="">
                </a>
            </div>
        </div>

        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/aqua-deck15.jpg" data-lightbox="gallery">
                    <img src="assets/images/aqua-deck15.jpg" alt="">
                </a>
            </div>
        </div>

        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/aqua-deck16.jpg" data-lightbox="gallery">
                    <img src="assets/images/aqua-deck16.jpg" alt="">
                </a>
            </div>
        </div>

        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/aqua-deck17.jpg" data-lightbox="gallery">
                    <img src="assets/images/aqua-deck17.jpg" alt="">
                </a>
            </div>
        </div>

        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/aqua-deck18.jpg" data-lightbox="gallery">
                    <img src="assets/images/aqua-deck18.jpg" alt="">
                </a>
            </div>
        </div>

        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/aqua-deck19.jpg" data-lightbox="gallery">
                    <img src="assets/images/aqua-deck19.jpg" alt="">
                </a>
            </div>
        </div>

        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/aqua-deck20.jpg" data-lightbox="gallery">
                    <img src="assets/images/aqua-deck20.jpg" alt="">
                </a>
            </div>
        </div>

        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/aqua-deck21.jpg" data-lightbox="gallery">
                    <img src="assets/images/aqua-deck21.jpg" alt="">
                </a>
            </div>
        </div>

        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/aqua-deck22.jpg" data-lightbox="gallery">
                    <img src="assets/images/aqua-deck22.jpg" alt="">
                </a>
            </div>
        </div>

        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/aqua-deck23.jpg" data-lightbox="gallery">
                    <img src="assets/images/aqua-deck23.jpg" alt="">
                </a>
            </div>
        </div>

        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/aqua-deck24.jpg" data-lightbox="gallery">
                    <img src="assets/images/aqua-deck24.jpg" alt="">
                </a>
            </div>
        </div>



    </div>

</div>
<!-- project -->


<!-- footer  -->
<?php
include_once 'includes/footer.php';
?>

<!-- footer  -->

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
<!-- Lightbox JavaScript -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/js/lightbox.min.js"></script>

<script src="assets/js/script.js"></script>

</body>

</html>
<?php 
include_once 'includes/header.php';
?>


    <!-- inner banner  -->

    <div class="container-fluid inner-banner"
        style="background-image: url('assets/images/become-a-supplier-banner.webp');">
    </div>

    <!-- inner banner  -->

    <!-- project -->
    <div class="container-fluid top-project py-5">
        <div class="container">

            <h2 class="short-title text-white"> <img src="assets/images/about-icon.png" class="small-icon-1" alt="">
                BECOME A SUPPLIER</h2>

                <p class="para1 text-white">Are you a Manufacturer? Are you a Product Provider? Do you provide a product or service that benefits potential clients in helping preserve , protect and maintain their assets? Do you have new technology showing consumers how to cut energy costs? Do you have products or services Then discuss getting you on our platform at virtually no upfront cost to you at all that make life easier while saving the environment? We have the sales and marketing know how and the install capability to create a Win, Win, Win for You , Us and our Customers. We are always open to new ideas, products and services. Let us show you how we can create a new income on your current, previous or future guests or customers! The future is now, do not miss out on this opportunity!</p>
                <p class="para1 text-white">You can gain valuable exposer and additional revenue by becoming a supplier. We will expose your product to thousands of consumers that use our platform. You can trust us to be your premiere marketing engagement partner, consistently helping you achieve your business goals and increase revenue. Contact us immediately to explore your potential supplier options</p>

            <div class="row">
                <div class="col-md-4">
                    <h3 class="title-3 text-white border text-center py-1">AMERICAN DOCK®</h3>
                </div>
                <div class="col-md-4">
                    <h3 class="title-3 text-white border text-center py-1">GREAT LAKES®</h3>
                </div>
                <div class="col-md-4">
                    <h3 class="title-3 text-white border text-center py-1">SHORELINE®</h3>
                </div>
                <div class="col-md-4">
                    <h3 class="title-3 text-white border text-center py-1">AQUALIFT®</h3>
                </div>
                <div class="col-md-4">
                    <h3 class="title-3 text-white border text-center py-1">HARBOR MASTER®</h3>
                </div>
                <div class="col-md-4">
                    <h3 class="title-3 text-white border text-center py-1">SHOREMATE®</h3>
                </div>
                <div class="col-md-4">
                    <h3 class="title-3 text-white border text-center py-1">AQUA-MATIC®</h3>
                </div>
                <div class="col-md-4">
                    <h3 class="title-3 text-white border text-center py-1">HEWITT®</h3>
                </div>
                <div class="col-md-4">
                    <h3 class="title-3 text-white border text-center py-1">SHOREMASTER®</h3>
                </div>
                <div class="col-md-4">
                    <h3 class="title-3 text-white border text-center py-1">BADGER®</h3>
                </div>
                <div class="col-md-4">
                    <h3 class="title-3 text-white border text-center py-1">LAKE SORE PRODUCTS (LSP)®
                    </h3>
                </div>
                <div class="col-md-4">
                    <h3 class="title-3 text-white border text-center py-1">SHORESTATION®</h3>
                </div>
                <div class="col-md-4">
                    <h3 class="title-3 text-white border text-center py-1">BASTA®</h3>
                </div>
                <div class="col-md-4">
                    <h3 class="title-3 text-white border text-center py-1">MAX DOCKS®</h3>
                </div>
                <div class="col-md-4">
                    <h3 class="title-3 text-white border text-center py-1">SUMMIT MARINE®</h3>
                </div>
                <div class="col-md-4">
                    <h3 class="title-3 text-white border text-center py-1">BEACH KING®</h3>
                </div>
                <div class="col-md-4">
                    <h3 class="title-3 text-white border text-center py-1">MIDLANDER®</h3>
                </div>
                <div class="col-md-4">
                    <h3 class="title-3 text-white border text-center py-1">STARR®</h3>
                </div>
                <div class="col-md-4">
                    <h3 class="title-3 text-white border text-center py-1">CAPTAINS CHOICE®</h3>
                </div>
                <div class="col-md-4">
                    <h3 class="title-3 text-white border text-center py-1">NEWMANS®</h3>
                </div>
                <div class="col-md-4">
                    <h3 class="title-3 text-white border text-center py-1">SUNCHASER® / PREMIER METALS</h3>
                </div>
                <div class="col-md-4">
                    <h3 class="title-3 text-white border text-center py-1">CUSTOM PORTABLE®</h3>
                </div>
                <div class="col-md-4">
                    <h3 class="title-3 text-white border text-center py-1">NUCRAFT/CRAFTLANDER® </h3>
                </div>
                <div class="col-md-4">
                    <h3 class="title-3 text-white border text-center py-1">TRITON®</h3>
                </div>
                <div class="col-md-4">
                    <h3 class="title-3 text-white border text-center py-1">WATERWAY®</h3>
                </div>
                <div class="col-md-4">
                    <h3 class="title-3 text-white border text-center py-1">RGC®</h3>
                </div>
                <div class="col-md-4">
                    <h3 class="title-3 text-white border text-center py-1">EZ DOCK®</h3>
                </div>
                <div class="col-md-4">
                    <h3 class="title-3 text-white border text-center py-1">WALKS ON WATER®</h3>
                </div>
                <div class="col-md-4">
                    <h3 class="title-3 text-white border text-center py-1">PORTA-DOCK®</h3>
                </div>
                <div class="col-md-4">
                    <h3 class="title-3 text-white border text-center py-1">DAKA®</h3>
                </div>
                <div class="col-md-4">
                    <h3 class="title-3 text-white border text-center py-1">FLOE®</h3>
                </div>
                <div class="col-md-4">
                    <h3 class="title-3 text-white border text-center py-1">SEA-LEGS®</h3>
                </div>
                <div class="col-md-4">
                    <h3 class="title-3 text-white border text-center py-1">WAGNER WORX</h3>
                </div>
                <div class="col-md-4">
                    <h3 class="title-3 text-white border text-center py-1">COASTLINE</h3>
                </div>
                <div class="col-md-4">
                    <h3 class="title-3 text-white border text-center py-1">AQUA MARINE DECK</h3>
                </div>
                <div class="col-md-4">
                    <h3 class="title-3 text-white border text-center py-1">ATLANTIC ALUMINUM</h3>
                </div>
                <div class="col-md-4">
                    <h3 class="title-3 text-white border text-center py-1">HYDRO-SHIELD</h3>
                </div>
                <div class="col-md-4">
                    <h3 class="title-3 text-white border text-center py-1">BOAT OUTFITTERS</h3>
                </div>
                <div class="col-md-4">
                    <h3 class="title-3 text-white border text-center py-1">DOCK SUPPLIERS</h3>
                </div>
              
            </div>

        </div>


    </div>
    <!-- project -->


   <!-- footer  -->
   <?php 
include_once 'includes/footer.php';
?>

<!-- footer  -->

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"
        integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <!-- Lightbox JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/js/lightbox.min.js"></script>

    <script src="assets/js/script.js"></script>

</body>

</html>
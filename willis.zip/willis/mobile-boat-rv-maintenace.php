<?php
include_once 'includes/header.php';
?>

<!-- navbar  -->

<!-- inner banner  -->

<div class="container-fluid inner-banner" style="background-image: url('assets/images/mobile-boat-rv-maintenace-banner.png');"></div>

<!-- inner banner  -->

<div class="container about p-5">
    <div class="row">
        <div class="col-lg-6 my-3 d-flex justify-content-center align-items-center px-lg-5">
            <img src="assets/images/mobile-boat-rv-maintenace-about.png" class="w-100 rounded" height="300" alt="">
        </div>
        <div class="col-lg-6 my-3 px-lg-5">

            <h3 class="title-3">Maintaining Your Boat And R.V. Will Help Extend The Life Of Your Investment</h3>

            <div class="my-4">
                <p class="para1">When you decide to buy a boat, maintaining it in good condition is of the utmost importance. Too many people who seem to be enthusiastic about boating when they buy their first boat fail to take care of it regularly, and thus the boat falls into disrepair, and the owners use it less and less.</p>
                <p class="para1">There are many basic tasks that you can do to keep your boat in good condition, such as regular cleaning and checking the oil levels. Other things, however, may require you to hire a boat mechanic to undertake a more complex task. It can take a long time and much technical knowledge to learn how to fix and maintain a boat’s engine, so a mechanic is often the best port of call.
                </p>

            </div>
        </div>
    </div>

    <div class="maintenace">

        <div class="row border border-dark maintenace-services">
            <div class="col-md-6 border border-dark">
                <p>Boats</p>
                <ol>
                    <li>Filter Service</li>
                    <li>Oil Changes</li>
                    <li>Winterization</li>
                    <li>Spark Plugs</li>
                    <li>Water Pumps</li>
                    <li>Electrical Services</li>
                    <li>Change Zincs</li>
                    <li>Prop Services</li>
                </ol>
            </div>
            <div class="col-md-6 border border-dark">
                <p>R.V.</p>

                <ol>
                    <li>Filter Service</li>
                    <li>Oil Changes</li>
                    <li>Winterization</li>
                    <li>Spark Plugs</li>
                    <li>Wheel Bearing Service</li>
                    <li>Slide-Out Service</li>
                    <li>Generator Service</li>
                </ol>
            </div>
        </div>
    </div>

    <p class="para1 mt-4">
        Every Boat and RV needs regular maintenance. Take the guesswork out of these maintenance tasks and stick to a schedule by allowing our service team to do this work for you and keep your Boat and RV in excellent condition. Here’s a list of the main maintenance services we commonly provide:
    </p>

 
    
</div>


<!-- project -->
<div class="container-fluid project py-5">
       <h2 class="title-2 text-center">MAINTENANCE SERVICES</h2>

    <div class="row justify-content-center">
        <div class="col-lg-2 col-md-3 col-sm-4 my-2">
            <div class="card service-card1">
                <img class="card-img-top" src="assets/images/mobile-boat-rv-maintenace-drive.png" alt="Card image">
                <div class="card-body py-0">
                    <h5 class="card-title text-center mt-3 fw-bold">Drive Services</h5>
                </div>
            </div>
        </div>
        <div class="col-lg-2 col-md-3 col-sm-4 my-2">
            <div class="card service-card1">
                <img class="card-img-top" src="assets/images/mobile-boat-rv-maintenace-inboard.png" alt="Card image">
                <div class="card-body py-0">
                    <h5 class="card-title text-center mt-3 fw-bold">Inboard Repairs</h5>
                </div>
            </div>
        </div>
        <div class="col-lg-2 col-md-3 col-sm-4 my-2">
            <div class="card service-card1">
                <img class="card-img-top" src="assets/images/mobile-boat-rv-maintenace-prop.png" alt="Card image">
                <div class="card-body py-0">
                    <h5 class="card-title text-center mt-3 fw-bold">Prop Repairs</h5>
                </div>
            </div>
        </div>
        <div class="col-lg-2 col-md-3 col-sm-4 my-2">
            <div class="card service-card1">
                <img class="card-img-top" src="assets/images/mobile-boat-rv-maintenace-inboard.png" alt="Card image">
                <div class="card-body py-0">
                    <h5 class="card-title text-center mt-3 fw-bold">Outboard Repairs</h5>
                </div>
            </div>
        </div>
        <div class="col-lg-2 col-md-3 col-sm-4 my-2">
            <div class="card service-card1">
                <img class="card-img-top" src="assets/images/mobile-boat-rv-maintenace-winterizing.png" alt="Card image">
                <div class="card-body py-0">
                    <h5 class="card-title text-center mt-3 fw-bold">Winterizing Package</h5>
                </div>
            </div>
        </div>
    </div>
    
    <div class="project-title">
            <h2 class="title text-center">“WE OFFER SERVICES ON ALL MAKES AND MODELS”</h2>
            
        </div>


    <div class="row justify-content-center mt-4">
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/mobile-boat-rv-maintenace1.jpg" data-lightbox="gallery">
                    <img src="assets/images/mobile-boat-rv-maintenace1.jpg" alt="">
                </a>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/mobile-boat-rv-maintenace2.jpg" data-lightbox="gallery">
                    <img src="assets/images/mobile-boat-rv-maintenace2.jpg" alt="">
                </a>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/mobile-boat-rv-maintenace3.jpg" data-lightbox="gallery">
                    <img src="assets/images/mobile-boat-rv-maintenace3.jpg" alt="">
                </a>
            </div>
        </div>


    </div>

</div>
<!-- project -->


<!-- footer  -->
<?php
include_once 'includes/footer.php';
?>

<!-- footer  -->

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
<!-- Lightbox JavaScript -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/js/lightbox.min.js"></script>

<script src="assets/js/script.js"></script>

</body>

</html>
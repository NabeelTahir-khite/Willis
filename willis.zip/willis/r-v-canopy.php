<?php 
include_once 'includes/header.php';
?>

<!-- navbar  -->
    <!-- inner banner  -->

    <div class="container-fluid inner-banner" style="background-image: url('assets/images/r-v-canopy-banner.jpg');"></div>

    <!-- inner banner  -->
    <!-- about  -->
    <div class="container about p-5">
        <div class="row">
            <div class="col-lg-6 my-3 d-flex justify-content-center align-items-center px-lg-5">
                <img src="assets/images/r-v-canopy-about.jpg" class="w-100 rounded" height="270" alt="">
            </div>
            <div class="col-lg-6 my-3 d-flex flex-column align-items-start justify-content-center px-lg-5">
             
                <h3 class="title-3">Custom R.V. Canopies with Vinyl or hard top options.</h3>
                <h3 class="title-3"> Buit to last and are removable easy to erect and easy to take down. Protect you’re your investment!</h3>

                <div class="mt-4">
                 
                    <p class="para1">Our R.V. Canopy Frames and  Covers are designed specifically for sun protection and will protect your asset all the way around no matter where it is parked.</p>

               
                </div>
            </div>

        </div>
    </div>
    <!-- about  -->

    <!-- project -->
    <div class="container-fluid project py-5">
       
            <h2 class="title text-center">YOU WILL HAVE IT MADE IN THE SHADE!</h2>
    

        <div class="row justify-content-center mt-4">

            <div class="col-md-4 col-sm-6 my-2">
                <div class="project-img">
                    <a href="assets/images/r-v-canopy1.jpg" data-lightbox="gallery">
                        <img src="assets/images/r-v-canopy1.jpg" alt="">
                    </a>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 my-2">
                <div class="project-img">
                    <a href="assets/images/r-v-canopy2.jpg" data-lightbox="gallery">
                        <img src="assets/images/r-v-canopy2.jpg" alt="">
                    </a>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 my-2">
                <div class="project-img">
                    <a href="assets/images/r-v-canopy3.jpg" data-lightbox="gallery">
                        <img src="assets/images/r-v-canopy3.jpg" alt="">
                    </a>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 my-2">
                <div class="project-img">
                    <a href="assets/images/r-v-canopy4.jpg" data-lightbox="gallery">
                        <img src="assets/images/r-v-canopy4.jpg" alt="">
                    </a>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 my-2">
                <div class="project-img">
                    <a href="assets/images/r-v-canopy5.jpg" data-lightbox="gallery">
                        <img src="assets/images/r-v-canopy5.jpg" alt="">
                    </a>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 my-2">
                <div class="project-img">
                    <a href="assets/images/r-v-canopy6.jpg" data-lightbox="gallery">
                        <img src="assets/images/r-v-canopy6.jpg" alt="">
                    </a>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 my-2">
                <div class="project-img">
                    <a href="assets/images/r-v-canopy7.jpg" data-lightbox="gallery">
                        <img src="assets/images/r-v-canopy7.jpg" alt="">
                    </a>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 my-2">
                <div class="project-img">
                    <a href="assets/images/r-v-canopy8.jpg" data-lightbox="gallery">
                        <img src="assets/images/r-v-canopy8.jpg" alt="">
                    </a>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 my-2">
                <div class="project-img">
                    <a href="assets/images/r-v-canopy9.jpg" data-lightbox="gallery">
                        <img src="assets/images/r-v-canopy9.jpg" alt="">
                    </a>
                </div>
            </div>
          
        </div>

    </div>
    <!-- project -->


   <!-- footer  -->
   <?php 
include_once 'includes/footer.php';
?>

<!-- footer  -->

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"
        integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <!-- Lightbox JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/js/lightbox.min.js"></script>

    <script src="assets/js/script.js"></script>

</body>

</html>
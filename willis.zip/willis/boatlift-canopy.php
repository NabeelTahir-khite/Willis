<?php 
include_once 'includes/header.php';
?>


    <!-- inner banner  -->

    <div class="container-fluid inner-banner" style="background-image: url('assets/images/boatlift-canopy.jpg');"></div>

    <!-- inner banner  -->

    <!-- about  -->
    <div class="container about p-5">
        <div class="row">
            <div class="col-lg-6 my-3 px-lg-5 d-flex justify-content-center align-items-center">
                <img src="assets/images/boatlift-canopy-about.jpg" class="w-100 rounded" alt="">
            </div>
            <div class="col-lg-6 my-3 px-lg-5">
          
                <h3 class="title-3">Custom Boatlift Cover Design Available for All Brands</h3>

                <div class="my-4">
                    <p class="para1">From style to compliance, we’ve got you covered. You can rest easy knowing we’ve
                        installed thousands of covers nationwide.</p>

                    <div class="row my-1">
                        <div class="col-2 px-0 d-flex justify-content-center align-items-center"> <svg aria-hidden="true"
                                class="circle-icon" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                                </path>
                            </svg></div>
                        <div class="col-10">
                            <h4 class="image-title">Frames engineered to withstand up to 180 mph winds</h4>
                        </div>
                    </div>
                    <div class="row my-1">
                        <div class="col-2 px-0 d-flex justify-content-center align-items-center"> <svg aria-hidden="true"
                                class="circle-icon" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                                </path>
                            </svg></div>
                        <div class="col-10">
                            <h4 class="image-title">Covers engineered to withstand up to 70 mph winds</h4>

                        </div>
                    </div>
                    <div class="row my-1">
                        <div class="col-2 px-0 d-flex justify-content-center align-items-center"> <svg aria-hidden="true"
                                class="circle-icon" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                                </path>
                            </svg></div>
                        <div class="col-10">
                            <h4 class="image-title">All aluminum frame construction</h4>

                        </div>
                    </div>
                    <div class="row my-1">
                        <div class="col-2 px-0 d-flex justify-content-center align-items-center"> <svg aria-hidden="true"
                                class="circle-icon" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                                </path>
                            </svg></div>
                        <div class="col-10">
                            <h4 class="image-title">Double rail reinforced frame</h4>

                        </div>
                    </div>
                    <div class="row my-1">
                        <div class="col-2 px-0 d-flex justify-content-center align-items-center"> <svg aria-hidden="true"
                                class="circle-icon" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                                </path>
                            </svg></div>
                        <div class="col-10">
                            <h4 class="image-title">Marine-grade vinyl covers</h4>

                        </div>
                    </div>
                    <div class="row my-1">
                        <div class="col-2 px-0 d-flex justify-content-center align-items-center"> <svg aria-hidden="true"
                                class="circle-icon" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                                </path>
                            </svg></div>
                        <div class="col-10">
                            <h4 class="image-title">Patented premium design</h4>

                        </div>
                    </div>
                    <div class="row my-1">
                        <div class="col-2 px-0 d-flex justify-content-center align-items-center"> <svg aria-hidden="true"
                                class="circle-icon" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                                </path>
                            </svg></div>
                        <div class="col-10">
                            <h4 class="image-title">Shock absorbent cords</h4>
                        </div>
                    </div>
                    <div class="row my-1">
                        <div class="col-2 px-0 d-flex justify-content-center align-items-center"> <svg aria-hidden="true"
                                class="circle-icon" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                                </path>
                            </svg></div>
                        <div class="col-10">
                            <h4 class="image-title">Removable cover</h4>

                        </div>
                    </div>
                    <div class="row my-1">
                        <div class="col-2 px-0 d-flex justify-content-center align-items-center"> <svg aria-hidden="true"
                                class="circle-icon" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                                </path>
                            </svg></div>
                        <div class="col-10">
                            <h4 class="image-title">Manufacturer Warranty</h4>

                        </div>
                    </div>
                </div>
            </div>
            
            <p class="para1">Canopies protect your valuable assets from nature’s harshest elements. Our patented boat lift covers and canopies are custom designed to fit your needs and protect your investment from the elements , especially sun damage!</p>

        </div>
        
        <h3 class="title-2 text-center">Features to Consider</h3>
        <p class="para1 text-center">When selecting a boat canopy in NC-SC-Ga, consider these essential features:</p>
        
        <div class="row">
            <div class="col-md-3 my-2 border border-dark-subtle rounded">
                <div class="text-center p-3">
                    <img class="card-img-top w-50 mx-auto" src="assets/images/boatlift-canopy-service1.png" alt="Feature image">
                    <div class="card-body py-0 px-2">
                        <h4 class="card-title text-center mt-3">Sturdy construction</h4>
                        <p class="mt-3">Ensure durability and stability against tidal changes and inclement weather</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 my-2 border border-dark-subtle rounded">
                <div class="text-center p-3">
                    <img class="card-img-top w-50 mx-auto" src="assets/images/boatlift-canopy-service2.png" alt="Feature image">
                    <div class="card-body py-0 px-2">
                        <h4 class="card-title text-center mt-3">Weather-resistant materials</h4>
                        <p class="mt-3">Protect your vessel from sudden storms, UV rays, and water damage</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 my-2 border border-dark-subtle rounded">
                <div class="text-center p-3">
                    <img class="card-img-top w-50 mx-auto" src="assets/images/boatlift-canopy-service3.png" alt="Feature image">
                    <div class="card-body py-0 px-2">
                        <h4 class="card-title text-center mt-3">Debris and bird droppings </h4>
                        <p class="mt-3">Keep your boat clean and free from canal debris and bird droppings</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 my-2 border border-dark-subtle rounded">
                <div class="text-center p-3">
                    <img class="card-img-top w-50 mx-auto" src="assets/images/boatlift-canopy-service4.png" alt="Feature image">
                    <div class="card-body py-0 px-2">
                        <h4 class="card-title text-center mt-3">Easy installation- removal- Maintenance </h4>
                        <p class="mt-3">Enjoy hassle-free handling for convenience and flexibility</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- about  -->

    <!-- project -->
    <div class="container-fluid project py-5">
       <h3 class="title text-center">WE CAN CUSTOM BUILD YOUR CANAPY TO FIT YOUR NEEDS</h3>

        <div class="row justify-content-center mt-4">
            

            <div class="col-md-4 col-sm-6 my-2">
                <div class="project-img">
                    <a href="assets/images/boatlift-canopy10.jpg" data-lightbox="gallery">
                        <img src="assets/images/boatlift-canopy10.jpg" alt="">
                    </a>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 my-2">
                <div class="project-img">
                    <a href="assets/images/boatlift-canopy11.jpg" data-lightbox="gallery">
                        <img src="assets/images/boatlift-canopy11.jpg" alt="">
                    </a>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 my-2">
                <div class="project-img">
                    <a href="assets/images/boatlift-canopy12.jpg" data-lightbox="gallery">
                        <img src="assets/images/boatlift-canopy12.jpg" alt="">
                    </a>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 my-2">
                <div class="project-img">
                    <a href="assets/images/boatlift-canopy13.jpg" data-lightbox="gallery">
                        <img src="assets/images/boatlift-canopy13.jpg" alt="">
                    </a>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 my-2">
                <div class="project-img">
                    <a href="assets/images/boatlift-canopy14.jpg" data-lightbox="gallery">
                        <img src="assets/images/boatlift-canopy14.jpg" alt="">
                    </a>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 my-2">
                <div class="project-img">
                    <a href="assets/images/boatlift-canopy15.jpg" data-lightbox="gallery">
                        <img src="assets/images/boatlift-canopy15.jpg" alt="">
                    </a>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 my-2">
                <div class="project-img">
                    <a href="assets/images/boatlift-canopy16.jpg" data-lightbox="gallery">
                        <img src="assets/images/boatlift-canopy16.jpg" alt="">
                    </a>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 my-2">
                <div class="project-img">
                    <a href="assets/images/boatlift-canopy17.jpg" data-lightbox="gallery">
                        <img src="assets/images/boatlift-canopy17.jpg" alt="">
                    </a>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 my-2">
                <div class="project-img">
                    <a href="assets/images/boatlift-canopy18.jpg" data-lightbox="gallery">
                        <img src="assets/images/boatlift-canopy18.jpg" alt="">
                    </a>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 my-2">
                <div class="project-img">
                    <a href="assets/images/boatlift-canopy19.jpg" data-lightbox="gallery">
                        <img src="assets/images/boatlift-canopy19.jpg" alt="">
                    </a>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 my-2">
                <div class="project-img">
                    <a href="assets/images/boatlift-canopy20.jpg" data-lightbox="gallery">
                        <img src="assets/images/boatlift-canopy20.jpg" alt="">
                    </a>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 my-2">
                <div class="project-img">
                    <a href="assets/images/boatlift-canopy21.jpg" data-lightbox="gallery">
                        <img src="assets/images/boatlift-canopy21.jpg" alt="">
                    </a>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 my-2">
                <div class="project-img">
                    <a href="assets/images/boatlift-canopy1.jpg" data-lightbox="gallery">
                        <img src="assets/images/boatlift-canopy1.jpg" alt="">
                    </a>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 my-2">
                <div class="project-img">
                    <a href="assets/images/boatlift-canopy2.jpg" data-lightbox="gallery">
                        <img src="assets/images/boatlift-canopy2.jpg" alt="">
                    </a>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 my-2">
                <div class="project-img">
                    <a href="assets/images/boatlift-canopy3.jpg" data-lightbox="gallery">
                        <img src="assets/images/boatlift-canopy3.jpg" alt="">
                    </a>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 my-2">
                <div class="project-img">
                    <a href="assets/images/boatlift-canopy4.jpg" data-lightbox="gallery">
                        <img src="assets/images/boatlift-canopy4.jpg" alt="">
                    </a>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 my-2">
                <div class="project-img">
                    <a href="assets/images/boatlift-canopy5.jpg" data-lightbox="gallery">
                        <img src="assets/images/boatlift-canopy5.jpg" alt="">
                    </a>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 my-2">
                <div class="project-img">
                    <a href="assets/images/boatlift-canopy6.png" data-lightbox="gallery">
                        <img src="assets/images/boatlift-canopy6.png" alt="">
                    </a>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 my-2">
                <div class="project-img">
                    <a href="assets/images/boatlift-canopy7.jpg" data-lightbox="gallery">
                        <img src="assets/images/boatlift-canopy7.jpg" alt="">
                    </a>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 my-2">
                <div class="project-img">
                    <a href="assets/images/boatlift-canopy8.jpg" data-lightbox="gallery">
                        <img src="assets/images/boatlift-canopy8.jpg" alt="">
                    </a>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 my-2">
                <div class="project-img">
                    <a href="assets/images/boatlift-canopy9.jpg" data-lightbox="gallery">
                        <img src="assets/images/boatlift-canopy9.jpg" alt="">
                    </a>
                </div>
            </div>
          
        </div>

    </div>
    <!-- project -->


   <!-- footer  -->
   <?php 
include_once 'includes/footer.php';
?>

<!-- footer  -->

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"
        integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <!-- Lightbox JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/js/lightbox.min.js"></script>

    <script src="assets/js/script.js"></script>

</body>

</html>
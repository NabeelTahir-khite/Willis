<?php 
session_start();
include_once 'includes/header.php';

?>

<!-- navbar  -->

    <!-- inner banner  -->
    <div class="container-fluid inner-banner" style="background-image: url('assets/images/contact-banner.jpg');"></div>
    <!-- inner banner  -->


    <!-- project -->
    <div class="container-fluid top-project py-5 ">
        <div class="container">

            <div class="row">

                <h2 class="title-2 text-white text-center">CONTACT US</h2>
                <p class="para1 text-center text-white px-4">Our team is ready to help. Just fill out the contact info
                    below and let us know the best time to reach you, how you found out about us, and most important,
                    what products and or services you are interested in. One of our technicians will then contact you to
                    discuss a solution that is right for you and then set an appointment to come out for a customized
                    quote or analysis.</p>
                <h2 class="title-2 text-white text-center">LET'S CONNECT</h2>

            </div>
            <div class="container contact">
                <?php
                if(isset($_SESSION['error'])){
                echo "<p class='text-danger text-center'>$_SESSION[error]</p>";
                unset($_SESSION['error']);
                }
                if(isset($_SESSION['success'])){
                echo "<p class='text-success text-center'>$_SESSION[success]</p>";
                unset($_SESSION['success']);
                }
                ?>
                <form class="row g-3" action="contact-process.php" method="POST" enctype="multipart/form-data">
                    <div class="col-md-6">
                        <label for="fname" class="form-label">First name</label>
                        <input type="text" class="form-control input" id="fname" name="fname" required>
                    </div>
                    <div class="col-md-6">
                        <label for="lname" class="form-label">Last name</label>
                        <input type="text" class="form-control input" id="lname" name="lname" required>
                    </div>
               
                    <div class="col-md-6">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control input" id="email" name="email" required>
                    </div>
                    <div class="col-md-6">
                        <label for="phone" class="form-label">Phone</label>
                        <input type="tel" class="form-control input" id="phone" name="phone" required>
                    </div>
                    <div class="col-md-12">
                        <label for="address" class="form-label">Address</label>
                        <input type="text" class="form-control input" id="address" name="address" required>
                    </div>
                    <div class="col-md-6">
                        <label for="city" class="form-label">City</label>
                        <input type="text" class="form-control input" id="city" name="city" required>
                    </div>
                    <div class="col-md-6">
                        <label for="zip" class="form-label">Zip</label>
                        <input type="number" class="form-control input" id="zip" name="zip" required>
                    </div>
                    <div class="col-md-6">
                        <label for="about" class="form-label">How did you hear about us?</label>
                        <select class="form-select input" id="about" name="about" required>
                            <option selected disabled value="">Select</option>
                            <option value="Boat Show">Boat Show</option>
                            <option value="Social Media">Social Media</option>
                            <option value="Brochure">Brochure</option>
                            <option value="Postcard-Mail Piece">Postcard-Mail Piece</option>
                            <option value="Referral">Referral</option>
                            <option value="Other">Other</option>
                          </select>
                    </div>
                    <div class="col-md-6">
                        <label for="interest" class="form-label">What is your primary interest in?</label>
                        <select class="form-select input" id="interest" name="interest" required>
                            <option selected disabled value="">Select</option>
                            <option value="Boatlift Canopy">Boatlift Canopy</option>
                            <option value="RV Canopy">RV Canopy</option>
                            <option value="Car Port- Deck- Patio Canopy">Car Port- Deck- Patio Canopy</option>
                            <option value="Commercial">Commercial</option>
                            <option value="Mobile Services">Mobile Services</option>
                            <option value="Solar">Solar</option>
                            <option value="Extras">Extras</option>
                            <option value="Employment">Employment</option>
                          </select>
                    </div>
                     <div class="col-md-12">
                        <label for="file" class="form-label">Attached File</label>
                        <input type="file" class="form-control input" id="file" name="file" >
                    </div>
                    <div class="col-md-12">
                        <label for="message" class="form-label">Message</label>
                        <textarea name="" class="form-control input" id="message" name="message"></textarea>
                    </div>
                    <div class="col-12 d-flex justify-content-center mt-5">
                        <button class="btn formBtn" type="submit">Send</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- project -->


  <!-- footer  -->
  <?php 
include_once 'includes/footer.php';
?>

<!-- footer  -->

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"
        integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <!-- Lightbox JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/js/lightbox.min.js"></script>

    <script src="assets/js/script.js"></script>

</body>

</html>
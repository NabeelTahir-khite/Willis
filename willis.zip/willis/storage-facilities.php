<?php
include_once 'includes/header.php';
?>

<!-- navbar  -->

<!-- inner banner  -->

<div class="container-fluid inner-banner" style="background-image: url('assets/images/storage-facilities-banner1.jpg');"></div>

<!-- inner banner  -->

<!-- about  -->
<div class="container about p-5">
    <div class="row">
        <div class="col-lg-6 my-3 d-flex justify-content-center align-items-center px-lg-5">
            <img src="assets/images/storage-facilities-about.jpg" class="w-100 rounded" alt="">
        </div>
        <div class="col-lg-6 my-3 d-flex flex-column justify-content-center align-items-start px-lg-5">
            <h2 class="short-title"> <img src="assets/images/about-icon.png" class="small-icon-1" alt="">
                COMMERCIAL WORK CENTERS</h2>
            <h3 class="title-3">Canopy Frames and Covers Available for your Business</h3>

            <div class="my-4">
                <p class="para1">Our Canopy Frames and Covers are designed to preserve the assets of the owners, and giving your business added value We keep the customer in mind and our canopy structures are built to last. Keep your customers valuable vehicles, RVs, boats and and equipment out of the heat , sun and elements. Protect your customers investment with our high quality canopies today!</p>


            </div>
        </div>

    </div>
</div>
<!-- about  -->

<!-- project -->
<div class="container-fluid project py-5">

        <h2 class="title text-center">CANOPY FRAMES AND COVERS AVAILABLE</h2>


    <div class="row justify-content-center mt-4">

        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/storage-facilities1.png" data-lightbox="gallery">
                    <img src="assets/images/storage-facilities1.png" alt="">
                </a>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/storage-facilities2.jpg" data-lightbox="gallery">
                    <img src="assets/images/storage-facilities2.jpg" alt="">
                </a>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/storage-facilities3.png" data-lightbox="gallery">
                    <img src="assets/images/storage-facilities3.png" alt="">
                </a>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/storage-facilities4.png" data-lightbox="gallery">
                    <img src="assets/images/storage-facilities4.png" alt="">
                </a>
            </div>
        </div>




    </div>

</div>
<!-- project -->


<!-- footer  -->
<?php 
include_once 'includes/footer.php';
?>

<!-- footer  -->

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
<!-- Lightbox JavaScript -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/js/lightbox.min.js"></script>

<script src="assets/js/script.js"></script>

</body>

</html>
<?php
include_once 'includes/header.php';
?>

<!-- navbar  -->

<!-- inner banner  -->

<div class="container-fluid inner-banner" style="background-image: url('assets/images/farm-equipment-banner.jpg');"></div>

<!-- inner banner  -->

<!-- about  -->
<div class="container about p-5">
    <div class="row">
        <div class="col-lg-6 my-3 d-flex justify-content-center align-items-center px-lg-5">
            <img src="assets/images/farm-equipment-about.jpg" class="w-100 rounded" alt="">
        </div>
        <div class="col-lg-6 my-3 d-flex flex-column justify-content-center align-items-start px-lg-5">
            <h2 class="short-title"> <img src="assets/images/about-icon.png" class="small-icon-1" alt="">
                COMMERCIAL FARMS</h2>
            <h3 class="title-3">Custom Cover Design Available for your Farm, Livestock, and Equipment</h3>

            <div class="my-4">
                <p class="para1">Our jobsite, garage, and business Canopy Frames and Covers are designed with the worker and business in mind and built to last. Keep your employees out of the heat and sun this summer!</p>


            </div>
        </div>

    </div>
</div>
<!-- about  -->

<!-- project -->
<div class="container-fluid project py-5">
   
        <h2 class="title text-center">CUSTOM COVER DESIGN AVAILABLE FOR YOUR FARM</h2>
    

    <div class="row justify-content-center mt-4">

        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/farm-equipment1.jpg" data-lightbox="gallery">
                    <img src="assets/images/farm-equipment1.jpg" alt="">
                </a>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/farm-equipment2.png" data-lightbox="gallery">
                    <img src="assets/images/farm-equipment2.png" alt="">
                </a>
            </div>
        </div>




    </div>

</div>
<!-- project -->


<!-- footer  -->
<?php 
include_once 'includes/footer.php';
?>

<!-- footer  -->

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
<!-- Lightbox JavaScript -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/js/lightbox.min.js"></script>

<script src="assets/js/script.js"></script>

</body>

</html>
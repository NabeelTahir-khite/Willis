<?php
include_once 'includes/header.php';
?>

<!-- navbar  -->

<!-- inner banner  -->

<div class="container-fluid inner-banner" style="background-image: url('assets/images/hydro-shield-banner1.png');"></div>

<!-- inner banner  -->

<!-- about  -->
<div class="container about p-5">
    <div class="row">
        <div class="col-lg-6 my-3 d-flex justify-content-center align-items-center px-lg-5">
            <img src="assets/images/hydro-shield-about.jpg" class="w-100 rounded" height="300" alt="">
        </div>
        <div class="col-lg-6 my-3 px-lg-5">

            <h3 class="title-3">Transformation Marine is a certified Dealer-Installer of Hydro-Shield</h3>

            <div class="my-4">
                <p class="para1"><strong>Hydro-Shield</strong> is a skeg-mounted hydrofoil that fits on most inboard and inboard/outboard motors, protects your boat’s propeller from underwater impacts, improves your boat’s performance, and shields marine mammals from injury.</p>
                <p class="para1"><strong>Hydro-Shield</strong> improves a boats performance while providing unsurpassed propeller protection from underwater impacts.
                    The hydrofoil design provides lift to the back of a boat, enabling a boat to get on plane faster and with less power. Reduced bow rise and porpoising is attained, as is improved fuel efficiency and turning performance.
                </p>

            </div>
        </div>
        <p class="para1">The <strong>Hydro-Shield</strong> also protects the propeller from damage due to underwater impacts at low and moderate speeds, reducing costly repairs to the propeller and gears.</p>
        <p class="para1">And because the propeller is shielded from underwater obstacles, it also shields marine mammals such as manatees and sea turtles from death and injury due to propeller strikes, and reduces the destruction of marine grasses from a boats propeller.
            Made from a thermoplastic compound, the Hydro-Shield absorbs impacts by deflecting without transferring 100% of the energy to the skeg, and its 316ths marine grade bracket system provides added protection to the skeg. 
        </p>
    </div>

</div>
<!-- about  -->

<div class="container">
    <div class="row">
        <div class="col-md-2 offset-md-1">
            <img src="assets/images/satisfaction.png" class="w-100" alt="">
        </div>
        <div class="col-md-8 d-flex flex-column justify-content-center align-items-center">
            <p class="para1">Made of flexible, high quality material, the Hydro-Shield not only protects the prop from underwater impacts, but also safeguards your skeg with its integrated skeg guards, ensuring long-lasting protection for both your skeg and propeller.</p>
            <a href="" class="getBtn p-3">Shop Now</a>
        </div>
    </div>
    <div class="row justify-content-center mt-4">



        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/hydro-shield1.png" data-lightbox="gallery">
                    <img src="assets/images/hydro-shield1.png" alt="">
                </a>
            </div>
            <h3 class="title-3 py-0 my-2">IMPROVE PERFORMANCE</h3>
            <p class="para1 py-0 my-2">Get On Plane Faster, Improve Handling, Controls Cavitation & Porpoising</p>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/hydro-shield2.jpg" data-lightbox="gallery">
                    <img src="assets/images/hydro-shield2.jpg" alt="">
                </a>
            </div>
            <h3 class="title-3 py-0 my-2">PROPELLER PROTECTION</h3>
            <p class="para1 py-0 my-2">Shield your Prop From Damage Due to Water Impacts & Line Entanglement</p>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/hydro-shield3.jpg" data-lightbox="gallery">
                    <img src="assets/images/hydro-shield3.jpg" alt="">
                </a>
            </div>
            <h3 class="title-3 py-0 my-2">SKEG GUARD</h3>
            <p class="para1 py-0 my-2">This Outboard Skeg Guard Reinforces Existing Skegs & Replaces Damaged Skegs</p>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/hydro-shield4.png" data-lightbox="gallery">
                    <img src="assets/images/hydro-shield4.png" alt="">
                </a>
            </div>
            <h3 class="title-3 py-0 my-2">PEACE OF MIND</h3>
            <p class="para1 py-0 my-2">Protects Marine Mammals From Death & Injury Due to Propeller Strikes</p>
        </div>



    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-md-6">
            <h2 class="short-title"> <img src="assets/images/about-icon.png" class="small-icon-1" alt="">
                HYDRO-SHIELD</h2>
            <h3 class="title-3">Standard Size Fin: 8.9 - 100 HP, Boats Up to 17'</h3>
            <p class="text-success fw-bold">$ 299.00 Installed </p>
            <p class="para1">Guaranteed improvement in overall performance and handling</p>

            <h4 class="image-title d-flex justify-content-start align-items-center"><span><svg aria-hidden="true" class="circle-icon mx-2" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                        <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                        </path>
                    </svg></span> For boats 17 feet and smaller, and outboards 8.9hp - 100hp (for stock brackets)
            </h4>

            <h4 class="image-title d-flex justify-content-start align-items-center"><span><svg aria-hidden="true" class="circle-icon mx-2" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                        <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                        </path>
                    </svg></span> Get on plane faster
            </h4>

            <h4 class="image-title d-flex justify-content-start align-items-center"><span><svg aria-hidden="true" class="circle-icon mx-2" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                        <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                        </path>
                    </svg></span> Plane at lower speeds and RPM settings
            </h4>

            <h4 class="image-title d-flex justify-content-start align-items-center"><span><svg aria-hidden="true" class="circle-icon mx-2" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                        <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                        </path>
                    </svg></span> Improves performance, fuel economy and overall handling
            </h4>

            <h4 class="image-title d-flex justify-content-start align-items-center"><span><svg aria-hidden="true" class="circle-icon mx-2" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                        <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                        </path>
                    </svg></span> Shields the propeller from damage due to underwater impacts
            </h4>

            <h4 class="image-title d-flex justify-content-start align-items-center"><span><svg aria-hidden="true" class="circle-icon mx-2" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                        <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                        </path>
                    </svg></span> Shields the propeller from damage due to underwater impacts
            </h4>

            <h4 class="image-title d-flex justify-content-start align-items-center"><span><svg aria-hidden="true" class="circle-icon mx-2" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                        <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                        </path>
                    </svg></span> Absorbs impacts </h4>
            <br>
            <h4 class="image-title d-flex justify-content-start align-items-center"><span><svg aria-hidden="true" class="circle-icon mx-2" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                        <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                        </path>
                    </svg></span> Controls cavitation and porpoising
            </h4>

            <h4 class="image-title d-flex justify-content-start align-items-center"><span><svg aria-hidden="true" class="circle-icon mx-2" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                        <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                        </path>
                    </svg></span> Fits on outboards and inboard/outboards
            </h4>
            <h4 class="image-title d-flex justify-content-start align-items-center"><span><svg aria-hidden="true" class="circle-icon mx-2" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                        <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                        </path>
                    </svg></span> Simple Installation</h4>

            <p class="para1">Made from an energy absorbing compounded glass filled thermoplastic
                Hydro Shield will get your boat on plane faster, allowing you to remain on plane at lower speeds and rpm's. It also improves handling and lowers your fuel burn at low and cruising RPM settings. Hydro-Shield will also protect your propeller from damage due to underwater impacts, and its 316th's marine grade stainless steel bracket system acts as a skeg guard, strengthening and reinforcing the skeg.</p>
            <p class="para1">Made from an energy-absorbing plastic compound, Hydro Shield can withstand impacts, natural or man-made. Even if your boat strikes natural hazards like rocks, coral, oyster beds, or sandbars, or man-made hazards like lobster and crab pots, Hydro Shield maintains its integrity and protects your prop and skeg</p>
        </div>
        <div class="col-md-6">
            <h2 class="short-title"> <img src="assets/images/about-icon.png" class="small-icon-1" alt="">
                HYDRO-SHIELD</h2>
            <h3 class="title-3">Large Size Fin: 100+ HP, Boats Greater Than 18'</h3>
            <p class="text-success fw-bold">$ 349.00 Installed </p>
            <p class="para1">Guaranteed improvement in overall performance and handling</p>


            <h4 class="image-title d-flex justify-content-start align-items-center"><span><svg aria-hidden="true" class="circle-icon mx-2" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                        <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                        </path>
                    </svg></span> For boats 18 feet and greater, and outboards 100hp - 425 hp as well as Inboard/Outboard's (Stern Drives)
            </h4>

            <h4 class="image-title d-flex justify-content-start align-items-center"><span><svg aria-hidden="true" class="circle-icon mx-2" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                        <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                        </path>
                    </svg></span> Get on plane faster
            </h4>

            <h4 class="image-title d-flex justify-content-start align-items-center"><span><svg aria-hidden="true" class="circle-icon mx-2" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                        <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                        </path>
                    </svg></span> Plane at lower speeds and RPM settings
            </h4>

            <h4 class="image-title d-flex justify-content-start align-items-center"><span><svg aria-hidden="true" class="circle-icon mx-2" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                        <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                        </path>
                    </svg></span> Improves performance, fuel economy and overall handling
            </h4>

            <h4 class="image-title d-flex justify-content-start align-items-center"><span><svg aria-hidden="true" class="circle-icon mx-2" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                        <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                        </path>
                    </svg></span> Shields the propeller from damage due to underwater impacts
            </h4>

            <h4 class="image-title d-flex justify-content-start align-items-center"><span><svg aria-hidden="true" class="circle-icon mx-2" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                        <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                        </path>
                    </svg></span> Reduces costly repairs to the propeller and lower unit gearing
            </h4>

            <h4 class="image-title d-flex justify-content-start align-items-center"><span><svg aria-hidden="true" class="circle-icon mx-2" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                        <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                        </path>
                    </svg></span> Absorbs impacts  </h4>
            <br>
            <h4 class="image-title d-flex justify-content-start align-items-center"><span><svg aria-hidden="true" class="circle-icon mx-2" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                        <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                        </path>
                    </svg></span> Controls cavitation and porpoising
            </h4>
            <h4 class="image-title d-flex justify-content-start align-items-center"><span><svg aria-hidden="true" class="circle-icon mx-2" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                        <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                        </path>
                    </svg></span> Fits on outboards and sterndrives
            </h4>
            <h4 class="image-title d-flex justify-content-start align-items-center"><span><svg aria-hidden="true" class="circle-icon mx-2" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                        <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                        </path>
                    </svg></span> Simple Installation </h4>

            <p class="para1">Made from an energy absorbing compounded glass filled thermoplastic
                Hydro Shield will get your boat on plane faster, allowing you to remain on plane at lower speeds and rpm's. It also improves handling and lowers your fuel burn at low and cruising RPM settings. Hydro-Shield will also protect your propeller from damage due to underwater impacts, and its 316th's marine grade stainless steel bracket system acts as a skeg guard, strengthening and reinforcing the skeg.</p>
            <p class="para1">Made from an energy-absorbing plastic compound, Hydro Shield can withstand impacts, natural or man-made. Even if your boat strikes natural hazards like rocks, coral, oyster beds, or sandbars, or man-made hazards like lobster and crab pots, Hydro Shield maintains its integrity and protects your prop and skeg.</p>
        </div>
    </div>
</div>
<div class="container my-2">
    <div class="col-8 offset-2">
        <img src="assets/images/hydro-shield-table.png" class="w-100 rounded" alt="">
    </div>
</div>
<!-- project -->
<div class="container-fluid project py-5">


    <div class="row justify-content-center mt-4">



        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/hydro-shield5.jpg" data-lightbox="gallery">
                    <img src="assets/images/hydro-shield5.jpg" alt="">
                </a>
            </div>
        </div>


        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/hydro-shield6.jpg" data-lightbox="gallery">
                    <img src="assets/images/hydro-shield6.jpg" alt="">
                </a>
            </div>
        </div>


        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/hydro-shield7.jpg" data-lightbox="gallery">
                    <img src="assets/images/hydro-shield7.jpg" alt="">
                </a>
            </div>
        </div>


        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/hydro-shield8.jpg" data-lightbox="gallery">
                    <img src="assets/images/hydro-shield8.jpg" alt="">
                </a>
            </div>
        </div>


        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/hydro-shield9.jpg" data-lightbox="gallery">
                    <img src="assets/images/hydro-shield9.jpg" alt="">
                </a>
            </div>
        </div>


        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/hydro-shield10.jpg" data-lightbox="gallery">
                    <img src="assets/images/hydro-shield10.jpg" alt="">
                </a>
            </div>
        </div>


        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/hydro-shield11.jpg" data-lightbox="gallery">
                    <img src="assets/images/hydro-shield11.jpg" alt="">
                </a>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/hydro-shield12.jpg" data-lightbox="gallery">
                    <img src="assets/images/hydro-shield12.jpg" alt="">
                </a>
            </div>
        </div>





    </div>

</div>
<!-- project -->


<!-- footer  -->
<?php
include_once 'includes/footer.php';
?>

<!-- footer  -->

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
<!-- Lightbox JavaScript -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/js/lightbox.min.js"></script>

<script src="assets/js/script.js"></script>

</body>

</html>
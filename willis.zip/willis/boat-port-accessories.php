<?php
include_once 'includes/header.php';
?>

<!-- navbar  -->

<!-- inner banner  -->

<div class="container-fluid inner-banner" style="background-image: url('assets/images/boat-port-accessories-banner2.jpg');"></div>

<!-- inner banner  -->

<!-- about  -->
<div class="container about p-5">
    <div class="row">
        <div class="col-lg-6 my-3 d-flex justify-content-center align-items-center px-lg-5">
            <img src="assets/images/boat-port-accessories-about.png" class="w-100 rounded" height="300" alt="">
        </div>
        <div class="col-lg-6 my-3 px-lg-5">

            <h3 class="title-3">RESIDENTIAL & COMMERCIAL  BOATPORTS</h3>

            <div class="my-4">
                <p class="para1">Keeping your boat high and dry has never been so easy. Our BoatPorts are a simple and stable drive-on, drive-off method of docking for boats in a wide range of sizes up to 5,000 lbs. Removable and changeable bunks can accommodate hull shapes from flat-bottoms to deep-Vs, making this the perfect choice for boats including skiffs, fishing boats, and jet boats. The EZ BoatPort is also available with side extensions for additional walk-around room and access to the sides of your boat for cleaning, maintenance, and covering</p>
                <p class="para1">No matter what kinds of boats will be docking on your waterway and no matter what your needs might be,OUR  We can find the options you need. Our drive-on floating boat docks also make docking a snap, even for less seasoned boaters.
                    Best of all, OUR Dock lets you spend more time on the water or on your business, because our boat ports are almost entirely maintenance-free. They are durable and made to last. They will not require repainting and will not rot. Even in rough waters and harsh weather, these boat ports stay stable, protecting boats more thoroughly than many styles of traditional ports.</p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <h3 class="title-2">BOATPORT® FEATURES:</h3>

                <h4 class="image-title d-flex justify-content-start align-items-center"><span><svg aria-hidden="true" class="circle-icon mx-2" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                            <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                            </path>
                        </svg></span> Configurations to fit multiple boats shapes and sizes
                </h4>

                <h4 class="image-title d-flex justify-content-start align-items-center"><span><svg aria-hidden="true" class="circle-icon mx-2" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                            <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                            </path>
                        </svg></span>Dry storage to extend the life of your boat
                </h4>

                <h4 class="image-title d-flex justify-content-start align-items-center"><span><svg aria-hidden="true" class="circle-icon mx-2" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                            <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                            </path>
                        </svg></span> Self-floating chambers that move with the changing water levels
                </h4>

                <h4 class="image-title d-flex justify-content-start align-items-center"><span><svg aria-hidden="true" class="circle-icon mx-2" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                            <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                            </path>
                        </svg></span>Works with existing floating or fixed docks

                </h4>

                <h4 class="image-title d-flex justify-content-start align-items-center"><span><svg aria-hidden="true" class="circle-icon mx-2" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                            <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                            </path>
                        </svg></span>Can be used in as little as 2 ft. of water

                </h4>

                <h4 class="image-title d-flex justify-content-start align-items-center"><span><svg aria-hidden="true" class="circle-icon mx-2" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                            <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                            </path>
                        </svg></span>No winching, cranking or hoisting

                    <h4 class="image-title d-flex justify-content-start align-items-center"><span><svg aria-hidden="true" class="circle-icon mx-2" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                                </path>
                            </svg></span>Floating boat dock kits available with 6 air assist options 
                    </h4>

                    <h4 class="image-title d-flex justify-content-start align-items-center"><span><svg aria-hidden="true" class="circle-icon mx-2" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                                </path>
                            </svg></span>Comes with an industry leading 10-year warranty
                    </h4>



            </div>
            <div class="col-md-6">
                <h3 class="title-2">ADD-ON FEATURES:</h3>

                <h4 class="image-title d-flex justify-content-start align-items-center"><span><svg aria-hidden="true" class="circle-icon mx-2" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                            <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                            </path>
                        </svg></span>Two skid bunk options to fit a variety of hull shapes and sizes
                </h4>

                <h4 class="image-title d-flex justify-content-start align-items-center"><span><svg aria-hidden="true" class="circle-icon mx-2" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                            <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                            </path>
                        </svg></span>Up to three additional keel rollers for longer boats
                </h4>

                <h4 class="image-title d-flex justify-content-start align-items-center"><span><svg aria-hidden="true" class="circle-icon mx-2" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                            <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                            </path>
                        </svg></span>Supplemental flotation kit for added buoyancy
                </h4>

                <h4 class="image-title d-flex justify-content-start align-items-center"><span><svg aria-hidden="true" class="circle-icon mx-2" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                            <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                            </path>
                        </svg></span>Optional side extensions for additional walk-around room
                </h4>

                <h4 class="image-title d-flex justify-content-start align-items-center"><span><svg aria-hidden="true" class="circle-icon mx-2" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                            <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                            </path>
                        </svg></span>Flip-up front cleat to secure the boat to the port
                </h4>


            </div>
        </div>
    </div>

</div>
<!-- about  -->

<!--<div class="container">-->
    
<!--</div>-->

<!-- project -->
<div class="container-fluid project py-5">
    
    <div class="row">
        <h3 class="title-2 text-white mt-0 text-center">Boating Accessories & Marine Supply</h3>

        <div class="row">
            <div class="col-md-3 my-2">
                <div class="card p-3">
                    <img class="card-img-top" src="assets/images/boat-port-accessories-product1.jpg" alt="Card image">
                    <div class="card-body py-0">
                        <h4 class="card-title text-center mt-3">Drink Holders</h4>
                    </div>
                </div>
            </div>

            <div class="col-md-3 my-2">
                <div class="card p-3">
                    <img class="card-img-top" src="assets/images/boat-port-accessories-product2.jpg" alt="Card image">
                    <div class="card-body py-0">
                        <h4 class="card-title text-center mt-3">Cooler Accessories</h4>
                    </div>
                </div>
            </div>

            <div class="col-md-3 my-2">
                <div class="card p-3">
                    <img class="card-img-top" src="assets/images/boat-port-accessories-product3.jpg" alt="Card image">
                    <div class="card-body py-0">
                        <h4 class="card-title text-center mt-3">Tables</h4>
                    </div>
                </div>
            </div>

            <div class="col-md-3 my-2">
                <div class="card p-3">
                    <img class="card-img-top" src="assets/images/boat-port-accessories-product4.jpg" alt="Card image">
                    <div class="card-body py-0">
                        <h4 class="card-title text-center mt-3">Swim Platforms</h4>
                    </div>
                </div>
            </div>

            <div class="col-md-3 my-2">
                <div class="card p-3">
                    <img class="card-img-top" src="assets/images/boat-port-accessories-product5.jpg" alt="Card image">
                    <div class="card-body py-0">
                        <h4 class="card-title text-center mt-3">Anchors</h4>
                    </div>
                </div>
            </div>

            <div class="col-md-3 my-2">
                <div class="card p-3">
                    <img class="card-img-top" src="assets/images/boat-port-accessories-product6.jpg" alt="Card image">
                    <div class="card-body py-0">
                        <h4 class="card-title text-center mt-3">Helm Pads</h4>
                    </div>
                </div>
            </div>

            <div class="col-md-3 my-2">
                <div class="card p-3">
                    <img class="card-img-top" src="assets/images/boat-port-accessories-product7.jpg" alt="Card image">
                    <div class="card-body py-0">
                        <h4 class="card-title text-center mt-3">Ladders</h4>
                    </div>
                </div>
            </div>

            <div class="col-md-3 my-2">
                <div class="card p-3">
                    <img class="card-img-top" src="assets/images/boat-port-accessories-product8.jpg" alt="Card image">
                    <div class="card-body py-0">
                        <h4 class="card-title text-center mt-3">Grills</h4>
                    </div>
                </div>
            </div>

            <div class="col-md-3 my-2">
                <div class="card p-3">
                    <img class="card-img-top" src="assets/images/boat-port-accessories-product9.jpg" alt="Card image">
                    <div class="card-body py-0">
                        <h4 class="card-title text-center mt-3">Signs</h4>
                    </div>
                </div>
            </div>

            <div class="col-md-3 my-2">
                <div class="card p-3">
                    <img class="card-img-top" src="assets/images/boat-port-accessories-product10.jpg" alt="Card image">
                    <div class="card-body py-0">
                        <h4 class="card-title text-center mt-3">Dive Tank Holders</h4>
                    </div>
                </div>
            </div>

            <div class="col-md-3 my-2">
                <div class="card p-3">
                    <img class="card-img-top" src="assets/images/boat-port-accessories-product11.jpg" alt="Card image">
                    <div class="card-body py-0">
                        <h4 class="card-title text-center mt-3">Bow Pulpits</h4>
                    </div>
                </div>
            </div>

            <div class="col-md-3 my-2">
                <div class="card p-3">
                    <img class="card-img-top" src="assets/images/boat-port-accessories-product12.jpg" alt="Card image">
                    <div class="card-body py-0">
                        <h4 class="card-title text-center mt-3">Boat Sun Shades</h4>
                    </div>
                </div>
            </div>


        </div>

    </div>
    
    <div class="project-title">
            <h2 class="title text-center">WE OFFER ALL KINDS OF LOW  MAINTENEANCE DOCK SOLUTIONS </h2>
        
        </div>

    <div class="row justify-content-center mt-4">

        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/boat-port-accessories1.jpg" data-lightbox="gallery">
                    <img src="assets/images/boat-port-accessories1.jpg" alt="">
                </a>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/boat-port-accessories2.jpg" data-lightbox="gallery">
                    <img src="assets/images/boat-port-accessories2.jpg" alt="">
                </a>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/boat-port-accessories3.jpg" data-lightbox="gallery">
                    <img src="assets/images/boat-port-accessories3.jpg" alt="">
                </a>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/boat-port-accessories4.jpg" data-lightbox="gallery">
                    <img src="assets/images/boat-port-accessories4.jpg" alt="">
                </a>
            </div>
        </div>




    </div>

</div>
<!-- project -->


<!-- footer  -->
<?php
include_once 'includes/footer.php';
?>

<!-- footer  -->

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
<!-- Lightbox JavaScript -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/js/lightbox.min.js"></script>

<script src="assets/js/script.js"></script>

</body>

</html>
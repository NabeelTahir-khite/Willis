<?php 
include_once 'includes/header.php';
?>

<!-- navbar  -->

    <!-- inner banner  -->

    <div class="container-fluid inner-banner" style="background-image: url('assets/images/solar-banner.png');"></div>

    <!-- inner banner  -->

    <!-- about  -->
    <div class="container about p-5">
        <div class="row ">
            <div class="col-lg-6 my-3 d-flex justify-content-center align-items-center px-lg-5">
                <img src="assets/images/solar-about.jpg" class="w-100 rounded" alt="">
            </div>
            <div class="col-lg-6 my-3 px-lg-5">
                <h2 class="short-title"> <img src="assets/images/about-icon.png" class="small-icon-1" alt="">
                    SOLAR</h2>
             

                <div class="my-4">
                    <p class="para1">We provide Custom Design and Engineering for every new  system. We also provide the highest quality products, and we work directly with the best in the business Installation services.  Our customers can count on us from start to finish Nation Wide.</p>
                    <p class="para1">All we need is a current electric bill from your provider, then we can put together an accurate cost comparison to give you a clear understanding of the  alternative costs along with the many other reasons why switching to Solar is in your best interest.</p>
                    <p class="para1">With New Technology today, and the Federal , State and Local Incentives and mandates, Its a No Brainer!</p>
                    <p class="para1">Our  agents work with you to determine what solar system is right for you. Keep in mind the latest technology and advancements now offer you more value and savings. The federal, state and local incentives and rebates are amazing today. There has never been a better time to replace your electric bill with Solar than right now.</p>

               
                </div>
            </div>
            <div class="px-lg-5">

                <h3 class="title-3">THE INSTALLATION</h3>
                <p class="para1">Our solar power installation partners are carefully chosen, field-tested professionals who will handle the physical setup of your panels.</p>
                
                <h3 class="title-3">PARTNER INSTALLERS</h3>
                <p class="para1">Partner Installers are backed by years of experience in the details of rooftop solar: securing permits, mounting panels to homes of all sizes, and providing craftmanship backed by warranty.</p>
                
                <h3 class="title-3">TRANSFORMATION MARINE</h3>
                <p class="para1">Transformation Marine is there for you every step of the way. Our Solar Energy Experts are available for any questions that arise, no matter what step of your home solar journey, making sure you stay updated.</p>
                <p class="para1">Set an appointment to discuss your options and  give you a free cost analysis. Contact us now to start the process to see if solar is right for you.</p>
            </div>

        </div>


    </div>
    <!-- about  -->

    


    <!-- project -->
    <div class="container-fluid project py-5">
        <div class="project-title">
            <h2 class="title text-center">POWER YOUR LIFE WITH SOLAR ENERGY</h2>
            <p class="para text-center text-white">Rooftop home solar is causing an energy revolution across the country. Solar panels deliver the sun’s abundant energy to your home and help lower your electricity bills. Best of all, this clean, renewable power avoids the carbon footprint of other fuels. Transformation Marine is an authorized dealer of Freedom Forever, a trusted source of power for homes and businesses throughout USA, wants to help you get in on it.</p>
        </div>

        <div class="row justify-content-center mt-4">

            <div class="col-md-4 col-sm-6 my-2">
                <div class="project-img">
                    <a href="assets/images/solar1.png" data-lightbox="gallery">
                        <img src="assets/images/solar1.png" alt="">
                    </a>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 my-2">
                <div class="project-img">
                    <a href="assets/images/solar2.png" data-lightbox="gallery">
                        <img src="assets/images/solar2.png" alt="">
                    </a>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 my-2">
                <div class="project-img">
                    <a href="assets/images/solar3.png" data-lightbox="gallery">
                        <img src="assets/images/solar3.png" alt="">
                    </a>
                </div>
            </div>
     
          
          
        </div>

        <div class="container">

          <h2 class="title-2 text-center">WHY GO FOR SOLAR?</h2>

          <div class="row">
              <div class="col-lg-3 col-md-4 col-sm-6 d-flex flex-column justify-content-center align-items-center border py-3 px-4">
                  <img src="assets/images/state-we-serve-icon-cost.png" class="states-icon" alt="">
                  <h3 class="title-3 text-white">Low-Cost Power </h3>
                  <p class="para1 text-white">Solar power systems are low-cost power generation option, and, in some cases, it
                      can help make power bills zero or reduce to a minimum.
                  </p>
              </div>
              <div class="col-lg-3 col-md-4 col-sm-6 d-flex flex-column justify-content-center align-items-center border py-3 px-4">
                  <img src="assets/images/state-we-serve-icon-energy.png" class="states-icon" alt="">
                  <h3 class="title-3 text-white">Renewable Energy
                  </h3>
                  <p class="para1 text-white">Generating energy that produces no greenhouse gas emissions from fossil fuels and
                      contributes to reducing air pollution to a greater extent.

                  </p>
              </div>
              <div class="col-lg-3 col-md-4 col-sm-6 d-flex flex-column justify-content-center align-items-center border py-3 px-4">
                  <img src="assets/images/state-we-serve-icon-maintainance.png" class="states-icon" alt="">
                  <h3 class="title-3 text-white">Low Maintenance
                  </h3>
                  <p class="para1 text-white"> We ensure the right maintenance after the solar system installation and the
                      maintenance cost is very nominal.

                  </p>
              </div>
              <div class="col-lg-3 col-md-4 col-sm-6 d-flex flex-column justify-content-center align-items-center border py-3 px-4">
                  <img src="assets/images/state-we-serve-icon-eco.png" class="states-icon" alt="">
                  <h3 class="title-3 text-white">Eco-friendly
                  </h3>
                  <p class="para1 text-white">Save nature by saving the depletion of fossil fuels so it can be sustained for
                      future generations. Go Green, Go Solar.

                  </p>
              </div>
          </div>
      </div>

      <div class="row justify-content-center mt-4">

          <div class="col-md-4 col-sm-6 my-2">
              <div class="project-img">
                  <a href="assets/images/state-we-serve1.jpg" data-lightbox="gallery">
                      <img src="assets/images/state-we-serve1.jpg" alt="">
                  </a>
              </div>
          </div>
          <div class="col-md-4 col-sm-6 my-2">
              <div class="project-img">
                  <a href="assets/images/state-we-serve2.png" data-lightbox="gallery">
                      <img src="assets/images/state-we-serve2.png" alt="">
                  </a>
              </div>
          </div>
          <div class="col-md-4 col-sm-6 my-2">
              <div class="project-img">
                  <a href="assets/images/state-we-serve3.jpg" data-lightbox="gallery">
                      <img src="assets/images/state-we-serve3.jpg" alt="">
                  </a>
              </div>
          </div>
          <div class="col-md-4 col-sm-6 my-2">
              <div class="project-img">
                  <a href="assets/images/state-we-serve4.jpg" data-lightbox="gallery">
                      <img src="assets/images/state-we-serve4.jpg" alt="">
                  </a>
              </div>
          </div>


      </div>

    </div>
    <!-- project -->


    <!-- footer  -->
    <?php 
include_once 'includes/footer.php';
?>

    <!-- footer  -->

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"
        integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <!-- Lightbox JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/js/lightbox.min.js"></script>

    <script src="assets/js/script.js"></script>

</body>

</html>
<?php
include_once 'includes/header.php';
?>

<!-- navbar  -->

<!-- inner banner  -->

<div class="container-fluid inner-banner" style="background-image: url('assets/images/store-banner.jpg');"></div>

<!-- inner banner  -->

<!-- about  -->
<div class="container about p-5">
    <div class="row">
        <div class="col-lg-6 my-3 d-flex justify-content-center align-items-center px-lg-5">
            <img src="assets/images/store-about.webp" class="w-100 rounded" alt="">
        </div>
        <div class="col-lg-6 my-3 px-lg-5">
            <h2 class="short-title"> <img src="assets/images/about-icon.png" class="small-icon-1" alt="">
                STORE</h2>
            <h3 class="title-3">Store Items that our Customers Want..</h3>

            <div class="my-4">
                <p class="para">Our agents can also work with the consumer to determine if additional products are needed or wanted and if they are right for you. We are adding “Extra” products and services as we find them. If its quality and it helps our clients, protect their assets, save money or conserve energy we may just have it. If you have a product or service that you think would be a good fit , check out our Become a Supplier page and let us know. We will be offering our online store soon.
                    We deliver and do all the installs . Contact us now</p>


            </div>
        </div>

    </div>
</div>
<!-- about  -->

<!-- project -->
<div class="container-fluid top-project py-5">
    <div class="project-title">
        <h2>STORE ITEMS</h2>
    </div>

    <div class="row justify-content-center mt-4">

        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/store1.jpg" data-lightbox="gallery">
                    <img src="assets/images/store1.jpg" alt="">
                </a>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/store2.jpg" data-lightbox="gallery">
                    <img src="assets/images/store2.jpg" alt="">
                </a>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/store3.jpg" data-lightbox="gallery">
                    <img src="assets/images/store3.jpg" alt="">
                </a>
            </div>
        </div>



    </div>

</div>
<!-- project -->

<!-- footer  -->
<?php 
include_once 'includes/footer.php';
?>

<!-- footer  -->

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
<!-- Lightbox JavaScript -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/js/lightbox.min.js"></script>

<script src="assets/js/script.js"></script>

</body>

</html>
<?php
include_once 'includes/header.php';
?>

<!-- navbar  -->

<!-- about  -->
<div class="container about py-4">
    <div class="row">
        <div class="col-md-5 my-3">
            <img src="assets/images/marina-about.jpg" class="w-100 rounded" id="image" height="300" alt="">
            <div class="col-12 mt-2">
                <div class="owl-carousel owl-theme owl-loaded owl-drag">




                    <div class="owl-stage-outer">
                        <div class="owl-stage" style="transform: translate3d(-426px, 0px, 0px); transition: all 0s ease 0s; width: 1420px;">
                            <div class="owl-item " style="width: 132px; margin-right: 10px;">
                                <div class="item"><img src="assets/images/work-center2.jpg" alt="" class="w-100 img" height="120" onmouseenter="changeImage(this.src)"></div>
                            </div>
                            <div class="owl-item " style="width: 132px; margin-right: 10px;">
                                <div class="item"><img src="assets/images/work-center3.jpg" alt="" class="w-100 img" height="120" onmouseenter="changeImage(this.src)"></div>
                            </div>
                            <div class="owl-item " style="width: 132px; margin-right: 10px;">
                                <div class="item"><img src="assets/images/storage-facilities3.png" alt="" class="w-100 img" height="120" onmouseenter="changeImage(this.src)"></div>
                            </div>
                            <div class="owl-item " style="width: 132px; margin-right: 10px;">
                                <div class="item"><img src="assets/images/work-center2.jpg" alt="" class="w-100 img" height="120" onmouseenter="changeImage(this.src)"></div>
                            </div>
                            <div class="owl-item " style="width: 132px; margin-right: 10px;">
                                <div class="item"><img src="assets/images/wisconsin.jpg" alt="" class="w-100 img" height="120" onmouseenter="changeImage(this.src)"></div>
                            </div>

                        </div>
                    </div>
                    <div class="owl-nav disabled"><button type="button" role="presentation" class="owl-prev"><span aria-label="Previous">‹</span></button><button type="button" role="presentation" class="owl-next"><span aria-label="Next">›</span></button></div>
                    <div class="owl-dots"><button role="button" class="owl-dot active"><span></span></button><button role="button" class="owl-dot"><span></span></button></div>
                </div>
            </div>
        </div>
        <div class="col-md-7 my-3 px-lg-5">
            <p class="text-muted m-0">Fish Table</p>
            <h3 class="title-2 my-3">Custom Marina Design Covers Available</h3>
            <hr>

            <div class="my-4">
                <p class="para1">Planning and Manufacturing Large scale projects exceeding 50 cover installs as well as larger scaled installs is also our specialty.
                    We take special interest in your marina projects. Starting with a site visit and measurements we custom build each cover to fit your specific needs.</p>
                <ul>
                    <li>Item # FCS-39-4LMarine-grade aluminum frame with 4 angled legs</li>
                    <li>3/4" thick King Starboard® cutting top</li>
                    <li>Space saving mounting over edge of dock</li>
                    <li>Dimensions: 39"W x 19"D x 35-1/2"H</li>
                </ul>

                <div class="d-flex justify-content-between">
                    <div class="quantity-btn">

                        <div class="quantity">
                            <span class="para1">Quantity</span>
                            <button id="minus">-</button>
                            <input type="text" name="" value="1" id="quantity" readonly>
                            <button id="plus">+</button>

                        </div>

                        <!-- buy buttons  -->
                        <div class="btns mt-3">
                            <button class="cart">Add To Cart</button>
                        </div>
                    </div>
                    <div class="price-item">

                        <p class="text-success"><span class="badge text-bg-success">In Stock</span></p>
                        <p class="text-primary fw-bold">$487.66</p>
                    </div>

                </div>


            </div>
        </div>

    </div>
</div>
<!-- about  -->




<!-- footer  -->
<?php
include_once 'includes/footer.php';
?>

<!-- footer  -->

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
<!-- Lightbox JavaScript -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/js/lightbox.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js" integrity="sha512-bPs7Ae6pVvhOSiIcyUClR7/q2OAsRiovw4vAkX+zJbw3ShAeeqezq50RIIcIURq7Oa20rW2n2q+fyXBNcU9lrw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<script>
    $(".owl-carousel").owlCarousel({
        loop: true,
        margin: 10,
        responsive: {

            1000: {
                items: 3,
            },
        },
    });
</script>

<script src="assets/js/script.js"></script>
<script>
    function changeImage(source) {
        var image = document.getElementById('image');
        image.src = source;
    }

    let Sub = document.querySelector("#minus");
    let Add = document.querySelector("#plus");
    let quantityNumber = document.querySelector("#quantity");
    let currentValue = 1;

    Sub.addEventListener("click", function() {
        currentValue -= 1;
        if (currentValue <= 0) {
            Sub.style.cursor = 'no-drop'
            currentValue = 1;

        } else {
            Sub.style.cursor = 'pointer'
        }

        quantityNumber.value = currentValue;
    });

    Add.addEventListener("click", function() {
        currentValue += 1;
        if (currentValue > 0) {
            Sub.style.cursor = 'pointer'
        }
        quantityNumber.value = currentValue;

    });
 
</script>

</body>

</html>

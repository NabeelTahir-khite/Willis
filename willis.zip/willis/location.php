<?php
include_once 'includes/header.php';
?>

<!-- navbar  -->

<div class="container py-4" id="states">
    <!-- <h2 class="short-title text-center"> <img src="assets/images/about-icon.png" class="small-icon-1" alt="">
            Arizona</h2>
        <h2 class="title-3 text-center">THE GRAND CANYON STATE GOES SOLAR</h2> -->

    <!-- <div class="row">
            <div class="col-md-8">
                <h2 class="title-2">Why go solar in Arizona?</h2>
                <p class="para1">Many have already gone solar in the Grand Canyon State, and for good reason! Arizona
                    ranks 8th* in the nation for growth in the next 5 years. Investor owned utilities will source 15% of
                    their power from renewables by 2025, so you will see great incentives. There are many reasons why
                    residents are going solar, the biggest being “it just makes sense.”</p>
            </div>
            <div class="col-md-4 d-flex justify-content-center align-items-center">
                <a href="" class="btn getBtn">Get Quote Now</a>
            </div>
        </div> -->

    <!-- <div class="row mb-3">
            <div class="col-md-4">
                <img src="assets/images/arizona.jpg" class="w-100 rounded" alt="">
            </div>
            <div class="col-md-8">
                <h2 class="title-2">Solar incentives in Arizona*
                </h2>
                <p class="para1">Arizona’s Residential Solar and Wind Energy Systems Tax Credit offers a state tax
                    rebate to qualifying residents on the purchase price of a solar system of up to $1,000.
                    Additionally, the Solar Equipment Sales Tax Exemption frees you from any Arizona solar tax. You
                    won’t have to pay any sales tax on your system or additional property taxes on the added home
                    value. 
                </p>
                <p class="para1">Arizona homeowners are also eligible for the Solar Investment Tax Credit (ITC).*** The
                    ITC allows you to deduct 26 percent of the cost of installing a solar energy system from your
                    federal taxes.
                </p>
            </div>
        </div> -->

    <!-- <ol>
            <li>
                <h3 class="title-3">Save on energy</h3>
                <p class="para1">Energy rates increase every year, but solar has potential savings. We design your
                    system to offset your electricity consumption. This means you can produce all the energy you need,
                    even for those hot summers. Don’t worry, you can keep the AC on! With solar, your air conditioner
                    will run on sunshine during the day, letting you avoid possible high peak rates. 
                </p>
            </li>
            <li>
                <h3 class="title-3">Be prepared for outages</h3>
                <p class="para1">Scheduled maintenance or unforeseen weather can cause outages, especially in the
                    summer. The best thing you can do is be prepared with a solar system and batteries. In the event of
                    an outage, you can keep your house running. Talk to your dealer about what batteries are the right
                    fit for your system and lifestyle.

                </p>
            </li>
            <li>
                <h3 class="title-3">Preserve Arizona’s outdoors</h3>
                <p class="para1">Arizona is known for its deserts, mountains, canyons, and forests. It is no wonder that
                    Arizonans want to preserve their natural wonders. Every homeowner that installs solar is directly
                    contributing to the reduction of greenhouse gasses, such as CO2 from the state. Going solar may help
                    you save money while helping  the environment.
                </p>
            </li>
            <li>
                <h3 class="title-3">Have predictable payments
                </h3>
                <p class="para1">You may notice that as the temperatures rise, so does your energy bill. High Time of
                    Use rates (TOU) can make your bills unpredictable. Take the power back by avoiding them altogether.
                    Your energy system will produce electricity during the hottest times of day, and your batteries will
                    have your back at night. You may not even need to use any energy from your utility. 

                </p>
            </li>
            <li>
                <h3 class="title-3">Invest in your home
                </h3>
                <p class="para1">Many homeowners go solar to increase home equity. The average Arizona home is worth
                    $315,554, that is a 16.5% annual increase.* According to the National Renewable Energy Laboratory
                    (NREL), purchasing a solar power system can increase your home’s resale value by an average of 17%.
                    Solar is just another way to keep up with the market.** 
                </p>
            </li>
        </ol> -->
</div>

<!-- footer  -->
<?php 
include_once 'includes/footer.php';
?>

<!-- footer  -->

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
<!-- Lightbox JavaScript -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/js/lightbox.min.js"></script>

<script src="assets/js/script.js"></script>
<script src="assets/js/map.js"></script>



</body>

</html>
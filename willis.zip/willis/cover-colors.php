<?php
include_once 'includes/header.php';
?>

<!-- navbar  -->



<!-- about  -->
<div class="container about p-5">
    <div class="row">
        <div class="col-md-3">
            <img src="assets/images/cover-colors.jpg" class="w-100" alt="">
        </div>
        <div class="col-md-9 d-flex flex-column justify-content-center align-items-center">

            <h3 class="title-3">OUR VINYL TOPS ARE MADE BY PATIO 500 AND WE OVER 30 COLORS TO CHOOSE FROM! PICK YOUR FAVORITE</h3>

            <p class="para1">Transformation Marines goal is to deliver a product that you will be happy with for many years to come.
                Our Manufacturers only use quality materials in the manufacture of your boat lift cover. We will inspect each cover before it is delivered and after every installation to ensure it is done right the first time.</p>



        </div>

    </div>


    <div class="row justify-content-center my-2">
        <h4 class="title-2 text-center">When selecting your COVER COLORS please also include the #</h4>
        <div class="col-sm-9">

            <img src="assets/images/cover-colors-list1.png" class="w-100" alt="">
            <img src="assets/images/cover-colors-list2.png" class="w-100" alt="">
        </div>
    </div>

    <p class="para1"><strong>Protection from the sun </strong> – The sun is what makes our home a paradise. However, it can also be harsh and damaging. The gel coat on your boat not only makes it look shiny and new, it also makes clean-up a breeze. If left exposed in the sun the gel coat will break down and oxidized, leaving a chalky film on everything. A properly installed boat lift cover provides excellent coverage and protection from the sun. The material we use in our canopies has very good UV resistance and is backed by a 5 year limited warranty. On average the canopy will last 10-15 years. An added benefit of the shade provided by a boat lift cover is that it makes working on your boat during the heat of the day much more comfortable. You and your tools will stay cool while doing repairs or cleaning your boat. No more baking and feeling the burn of the afternoon sun!</p>
    <p class="para1"><strong>Protection from the weather</strong>– Even boat covers can fail to keep water from building up in your boat during our seasonal rain storms. While no solution is perfect, a boat lift cover does an excellent job of keeping water out of your boat. Any time that water is left standing in your boat it will increase the risk of algae and mold forming on your upholstery and in the corners of your boat interior. Just like working in the heat of the day can be uncomfortable, so can working in the rain. With a good boat lift cover installed, you can continue working on your boat during rain showers. It also keeps your detailing company on the job during unexpected rain showers, instead of having them run seeking shelter</p>
    <p class="para1"><strong>Better than a boat cover</strong>– When you are ready to get on the water, having to carefully remove a boat cover and store it can be a hassle. And after a great day on the water, the last thing you want to do is have to drag out the boat cover and maneuver it back in place. Also, many boat covers only provide protection for the interior of a boat and offer no protection for the hull. <br>
        Most boat covers are made of canvas based materials, which make production easier and less expensive. However, an average boat cover will not last more than a couple years before a replacement is needed. The canopy on our boat lift covers are designed to provide years of service and require no effort for normal use.
    </p>

</div>
<!-- about  -->


<!-- footer  -->
<?php
include_once 'includes/footer.php';
?>

<!-- footer  -->

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
<!-- Lightbox JavaScript -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/js/lightbox.min.js"></script>

<script src="assets/js/script.js"></script>

</body>

</html>
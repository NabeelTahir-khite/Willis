<?php
include_once 'includes/header.php';
?>

<!-- navbar  -->

<!-- inner banner  -->

<div class="container-fluid inner-banner" style="background-image: url('assets/images/car-port-canopy-banner.jpg'); background-position: center;"></div>

<!-- inner banner  -->

<!-- about  -->
<div class="container about p-5">
    <div class="row">
        <div class="col-lg-6 my-3 d-flex justify-content-center align-items-center px-lg-5">
            <img src="assets/images/car-port-canopy1.jpg" class="w-100 rounded" height="300px" alt="">
        </div>
        <div class="col-lg-6 my-3 d-flex flex-column justify-content-center align-items-start px-lg-5">
            <h2 class="short-title"> <img src="assets/images/about-icon.png" class="small-icon-1" alt="">
                RESIDENTIAL CAR PORTS</h2>
            <h3 class="title-3">Custom Carport Canopy Design</h3>

            <div class="my-4">
                <p class="para1">Using all aluminum and stainless-steel materials and 180 mph engineering ensures years of trouble-free enjoyment. Our Carport Canopies are manufactured to your site specs.
Let us help you protect your investment with the shade your vehicles deserves! No more fading paint  weather worn plastics.
 We also offer Solar Carport options with electric Charging stations. Let us helpyou turn the sun into your ally, by producing free energy to power your  electric cars or Golf carts! It’s a win win win !</p>


            </div>
        </div>

    </div>
</div>
<!-- about  -->

<!-- project -->
<div class="container-fluid project py-5">

        <h2 class="title text-center">CUSTOM CARPORT COVER DESIGN</h2>
 

    <div class="row justify-content-center mt-4">

        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/car-port-canopy1.jpg" data-lightbox="gallery">
                    <img src="assets/images/car-port-canopy1.jpg" alt="">
                </a>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/car-port-canopy2.jpg" data-lightbox="gallery">
                    <img src="assets/images/car-port-canopy2.jpg" alt="">
                </a>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/car-port-canopy3.png" data-lightbox="gallery">
                    <img src="assets/images/car-port-canopy3.png" alt="">
                </a>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/car-port-canopy4.jpg" data-lightbox="gallery">
                    <img src="assets/images/car-port-canopy4.jpg" alt="">
                </a>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/car-port-canopy5.png" data-lightbox="gallery">
                    <img src="assets/images/car-port-canopy5.png" alt="">
                </a>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/car-port-canopy6.jpg" data-lightbox="gallery">
                    <img src="assets/images/car-port-canopy6.jpg" alt="">
                </a>
            </div>
        </div>


    </div>

</div>
<!-- project -->

<!-- footer  -->
<?php 
include_once 'includes/footer.php';
?>

<!-- footer  -->

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
<!-- Lightbox JavaScript -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/js/lightbox.min.js"></script>

<script src="assets/js/script.js"></script>

</body>

</html>
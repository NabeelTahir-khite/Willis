<?php
include_once 'includes/header.php';
?>

<!-- navbar  -->

<!-- inner banner  -->

<div class="container-fluid inner-banner" style="background-image: url('assets/images/mobile-boat-rv-detailing-banner.jpg');"></div>

<!-- inner banner  -->
<div class="container about p-5">
<div class="row">
        <div class="col-lg-6 my-3 d-flex justify-content-center align-items-center px-lg-5">
            <img src="assets/images/mobile-boat-rv-detailing-about.jpg" class="w-100 rounded" height="300" alt="">
        </div>
        <div class="col-lg-6 my-3 px-lg-5">

            <h3 class="title-3">Regular Cleaning, Buffing And Waxing Your Boat And R.V. Can And Will Help Extend The Life Of Your Investment.</h3>
            <h3 class="title-3"> We Help Protect Your Exterior And Interior</h3>

            <div class="my-4">
                <p class="para1">To the marine and R.V. enthusiast, there is nothing more beautiful than the sight of a freshly cleaned and polished boat or RV! That said, detailing is about more than good looks – this is an important maintenance task that should not be overlooked. We recommend getting your boat and or RV waxed and detailed at least twice per season. Our custom detailing service includes a thorough Wash, Buff and Wax along with any other services your boat or RV needs to look its best – such as UV canvas and vinyl treatments.</p>

            </div>
        </div>
    </div>


</div>

<!-- project -->
<div class="container-fluid project py-5">
    <div class="project-title">
            <h2 class="title text-center">CUSTOM DETAILING FOR All MAKES AND MODELS</h2>
            
        </div>


    <div class="row justify-content-center mt-4">
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/mobile-boat-rv-detailing1.jpg" data-lightbox="gallery">
                    <img src="assets/images/mobile-boat-rv-detailing1.jpg" alt="">
                </a>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/mobile-boat-rv-detailing2.jpg" data-lightbox="gallery">
                    <img src="assets/images/mobile-boat-rv-detailing2.jpg" alt="">
                </a>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/mobile-boat-rv-detailing3.jpg" data-lightbox="gallery">
                    <img src="assets/images/mobile-boat-rv-detailing3.jpg" alt="">
                </a>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/mobile-boat-rv-detailing4.jpg" data-lightbox="gallery">
                    <img src="assets/images/mobile-boat-rv-detailing4.jpg" alt="">
                </a>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/mobile-boat-rv-detailing5.jpg" data-lightbox="gallery">
                    <img src="assets/images/mobile-boat-rv-detailing5.jpg" alt="">
                </a>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/mobile-boat-rv-detailing6.jpg" data-lightbox="gallery">
                    <img src="assets/images/mobile-boat-rv-detailing6.jpg" alt="">
                </a>
            </div>
        </div>


    </div>

</div>
<!-- project -->


<!-- footer  -->
<?php 
include_once 'includes/footer.php';
?>

<!-- footer  -->

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
<!-- Lightbox JavaScript -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/js/lightbox.min.js"></script>

<script src="assets/js/script.js"></script>

</body>

</html>
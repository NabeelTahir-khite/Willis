<?php 
include_once 'includes/header.php';
?>


    <!-- inner banner  -->

    <div class="container-fluid inner-banner"
        style="background-image: url('assets/images/become-an-affiliate-banner.jpg');">
    </div>

    <!-- inner banner  -->

    <!-- project -->
    <div class="container-fluid top-project py-5">
        <div class="container">

            <h2 class="short-title text-white"> <img src="assets/images/about-icon.png" class="small-icon-1" alt="">
                BECOME AN AFFILIATE</h2>

            <p class="para1 text-white">You can trust us to be your premiere sales marketing and Canopy partner,
                consistently helping you achieve your business goals and generating a new profit stream and or free
                exposer for you and your company through new technology and incentives.</p>
            <p class="para1 text-white">Affiliates are working in a model in which third-parties promote our products or
                services and receive a percentage of the sales or download traffic made as a result. It is typically
                considered a key part of modern sales and marketing. By teaming up with our inside sales staff , we make
                it easy for you to refer your friends , colleges and business relations that will benefit from our
                incentive offers products and Services. Once you have a good understanding of all the applications and
                different offerings and solutions that can be achieved with our incentives and platform.</p>

                <div class="d-flex justify-content-center">
                    
                    <img src="assets/images/become-an-affiliate-about.jpg" alt="">
                </div>

        </div>


    </div>
    <!-- project -->


   <!-- footer  -->
   <?php 
include_once 'includes/footer.php';
?>

<!-- footer  -->

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"
        integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <!-- Lightbox JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/js/lightbox.min.js"></script>

    <script src="assets/js/script.js"></script>

</body>

</html>
<?php
include_once 'includes/header.php';
?>

<!-- navbar  -->

<!-- inner banner  -->

<div class="container-fluid inner-banner" style="background-image: url('assets/images/docks-accessories-banner1.png');"></div>

<!-- inner banner  -->

<!-- about  -->
<div class="container about p-5">
    <div class="row">
        <div class="col-lg-6 my-3 d-flex justify-content-center align-items-center px-lg-5">
            <img src="assets/images/docks-accessories-about.jpg" class="w-100 rounded" height="300" alt="">
        </div>
        <div class="col-lg-6 my-3 px-lg-5">

            <h3 class="title-3">More Enjoyment from Your Residential Dock</h3>

            <div class="my-4">
                <p class="para1">Our residential docks, swim platforms, boat lifts, kayak and canoe launches and accessories are designed to help you make the most of the water at your home, cottage, vacation home or other residential property. Our lake home docks and other products can change the game for you when it comes to how you use the water.</p>
                <p class="para1">Our Dock products are not only innovative, but they’re also the last docks and accessories you’ll need. Our manufacturers installed there first docks 26 years ago and they are still in use in the water today.
                    The design of our docks, swim platforms and other products were built around the concept of durability! We believe you deserve more time in the water and shouldn’t be spending precious days or weeks repairing your dock or platform, repainting it, or fretting over it.
                </p>
            </div>
        </div>
        <div class="row">
       
                <h3 class="title-3">YOUR BEST BOAT DOCK INVESTMENT</h3>
                <p class="para1">We’ve made sure the type of Dock we provide is the best investment you make in your waterfront property! Our agents help by creating an attractive, modular and safe dock you can count on season after season. Our custom residential docks can be tailored to your exact needs, can carry a heavy load, look attractive and virtually never need maintenance or repainting. We even provide the option for you to design your dock.</p>
                <p class="para1">Our docks and platforms are slip-resistant and do not transfer heat quickly to skin. Our docks, platforms and other polyethylene products will not splinter or have any nails which can cause injuries, the way wooden docks sometimes do.</p>
                <p class="para1">Our docks are even environmentally friendly. They don’t cause any chemicals to leak into the water (the way treated lumber can) and they allow sun to filter into the water, protecting marine life. View our variety of residential dock applications today!</p>
        
                <h3 class="title-3">CUSTOM DOCK OPTIONS FOR YOUR HOME
                </h3>
                <p class="para1">You get to preview many <a href="https://www.ez-dock.com/products/dock-sections/" style="color:#c36;" target="_blank">dock section sizes and shapes</a> to choose from, allowing you to customize the exact waterfront look you want.</p>
                <p class="para1">Choose from <a href="https://www.ez-dock.com/market/swim-platforms/" style="color:#c36;" target="_blank">swim platforms</a>,<a href="https://www.ez-dock.com/products/boat-lifts/" style="color:#c36;" target="_blank">boat lifts</a> , <a href="https://www.ez-dock.com/products/ez-launch-for-kayaks/" style="color:#c36;" target="_blank">kayak and canoe launches</a>, <a href="https://www.ez-dock.com/gangways-for-docks/" style="color:#c36;" target="_blank">gangways</a>, <a href="https://www.ez-dock.com/market/ez-trail/" style="color:#c36;" target="_blank">floating walkways</a> and <a href="https://www.ez-dock.com/products/dock-accessories/" style="color:#c36;" target="_blank">accessories</a> in order to get the docking solution you need.</p>
                <p class="para1">Our docks are even environmentally friendly. They don’t cause any chemicals to leak into the water (the way treated lumber can) and they allow sun to filter into the water, protecting marine life. View our variety of residential dock applications today!</p>
                <p class="para1">Whether you want a floating dock for reading on, a lift for boating, a platform for swimming or any other product for making the most of your water, We can deliver the accessories and docks you want. The patented system for interlocking the components make our docks and other products easy to install.</p>
                <p class="para1">You have several options but when selecting your dock system remember that polyethylene docks and platforms are cooler to the touch when compared with other materials, ensuring your feet stay comfortable, even in hot weather. A slip-resistant texture molded right into the docks, platforms and other products can help reduce the risk of slip and fall incidents and provides a comfortable surface for bare feet to grip. Grooves right in the dock or platform channel water away from the surface, helping you avoid puddles which can also pose a slipping risk.
                    If you’re looking for a safe, long-lasting, <a href="https://www.ez-dock.com/all-products/" style="color:#c36;" target="_blank">low-maintenance dock option</a> for your waterfront property, Here at Transformation Marine, our friendly staff will be happy to discuss our solutions with you!
                </p>
           
        </div>
    </div>

</div>
<!-- about  -->




<!-- project -->
<div class="container-fluid project py-5">
    
     <div class="row">
        <h3 class="title-2 text-white text-center mt-0">Dock Accessories</h3>

        <div class="row">

            <div class="col-md-3 my-2">
                <a href="product.php?category=fish-tables">
                    <div class="card p-3">
                        <img class="card-img-top" src="assets/images/docks-accessories-product1.jpg" alt="Card image">

                    </div>
                </a>
            </div>

            <div class="col-md-3 my-2">
                <a href="">
                    <div class="card p-3">
                        <img class="card-img-top" src="assets/images/docks-accessories-product2.jpeg" alt="Card image">

                    </div>
                </a>
            </div>

            <div class="col-md-3 my-2">
                <a href="">
                    <div class="card p-3">
                        <img class="card-img-top" src="assets/images/docks-accessories-product3.jpeg" alt="Card image">

                    </div>
                </a>
            </div>

            <div class="col-md-3 my-2">
                <a href="">
                    <div class="card p-3">
                        <img class="card-img-top" src="assets/images/docks-accessories-product4.jpeg" alt="Card image">

                    </div>
                </a>
            </div>

            <div class="col-md-3 my-2">
                <a href="">
                    <div class="card p-3">
                        <img class="card-img-top" src="assets/images/docks-accessories-product5.jpeg" alt="Card image">

                    </div>
                </a>
            </div>

            <div class="col-md-3 my-2">
                <a href="">
                    <div class="card p-3">
                        <img class="card-img-top" src="assets/images/docks-accessories-product6.jpeg" alt="Card image">

                    </div>
                </a>
            </div>

            <div class="col-md-3 my-2">
                <a href="">
                    <div class="card p-3">
                        <img class="card-img-top" src="assets/images/docks-accessories-product7.jpeg" alt="Card image">

                    </div>
                </a>
            </div>

            <div class="col-md-3 my-2">
                <a href="">
                    <div class="card p-3">
                        <img class="card-img-top" src="assets/images/docks-accessories-product8.png" alt="Card image">

                    </div>
                </a>
            </div>

            <div class="col-md-3 my-2">
                <a href="">
                    <div class="card p-3">
                        <img class="card-img-top" src="assets/images/docks-accessories-product9.jpeg" alt="Card image">

                    </div>
                </a>
            </div>

            <div class="col-md-3 my-2">
                <a href="">
                    <div class="card p-3">
                        <img class="card-img-top" src="assets/images/docks-accessories-product10.png" alt="Card image">

                    </div>
                </a>
            </div>

            <div class="col-md-3 my-2">
                <a href="">
                    <div class="card p-3">
                        <img class="card-img-top" src="assets/images/docks-accessories-product11.png" alt="Card image">

                    </div>
                </a>
            </div>

            <div class="col-md-3 my-2">
                <a href="">
                    <div class="card p-3">
                        <img class="card-img-top" src="assets/images/docks-accessories-product12.png" alt="Card image">

                    </div>
                </a>
            </div>

            <div class="col-md-3 my-2">
                <a href="">
                    <div class="card p-3">
                        <img class="card-img-top" src="assets/images/docks-accessories-product13.jpg" alt="Card image">

                    </div>
                </a>
            </div>

            <div class="col-md-3 my-2">
                <a href="">
                    <div class="card p-3">
                        <img class="card-img-top" src="assets/images/docks-accessories-product14.jpeg" alt="Card image">

                    </div>
                </a>
            </div>

            <div class="col-md-3 my-2">
                <a href="">
                    <div class="card p-3">
                        <img class="card-img-top" src="assets/images/docks-accessories-product15.jpeg" alt="Card image">

                    </div>
                </a>
            </div>

            <div class="col-md-3 my-2">
                <a href="">
                    <div class="card p-3">
                        <img class="card-img-top" src="assets/images/docks-accessories-product16.jpeg" alt="Card image">

                    </div>
                </a>
            </div>

            <div class="col-md-3 my-2">
                <a href="">
                    <div class="card p-3">
                        <img class="card-img-top" src="assets/images/docks-accessories-product17.jpeg" alt="Card image">

                    </div>
                </a>
            </div>

            <div class="col-md-3 my-2">
                <a href="">
                    <div class="card p-3">
                        <img class="card-img-top" src="assets/images/docks-accessories-product18.png" alt="Card image">
                    </div>
                </a>
            </div>

        </div>
    </div>
   <div class="project-title">
            <h2 class="title text-center">WE OFFER ALL KINDS OF LOW  MAINTENEANCE DOCK SOLUTIONS </h2>
         
        </div>
   

    <div class="row justify-content-center mt-4">



        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/docks-accessories1.jpg" data-lightbox="gallery">
                    <img src="assets/images/docks-accessories1.jpg" alt="">
                </a>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/docks-accessories2.jpg" data-lightbox="gallery">
                    <img src="assets/images/docks-accessories2.jpg" alt="">
                </a>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/docks-accessories3.jpg" data-lightbox="gallery">
                    <img src="assets/images/docks-accessories3.jpg" alt="">
                </a>
            </div>
        </div>




    </div>

</div>
<!-- project -->


<!-- footer  -->
<?php
include_once 'includes/footer.php';
?>

<!-- footer  -->

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
<!-- Lightbox JavaScript -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/js/lightbox.min.js"></script>

<script src="assets/js/script.js"></script>

</body>

</html>
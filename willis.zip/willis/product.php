<?php
include_once 'includes/header.php';
?>

<!-- navbar  -->

<!-- inner banner  -->

<div class="container-fluid inner-banner" id="banner" style="background-image: url('assets/images/banner1.jpg');"></div>

<!-- inner banner  -->

<!-- about  -->
<div class="container about p-5" id="data">
    <div class="row">
        <div class="col-lg-6 my-3 d-flex justify-content-center align-items-center px-lg-5">
            <img src="" class="w-100 rounded" id="about-img" height="300" alt="">
        </div>
        <div class="col-lg-6 my-3 px-lg-5">
            <h2 class="title-2"> <img src="assets/images/about-icon.png" class="small-icon-1" alt="">
                <span id="title"></span>
            </h2>

            <div class="my-4" id="content">
              <!-- dynamic content from js -->
            </div>
        </div>

    </div>


    <div class="row" id="category">
              <!-- dynamic content from js -->
    </div>

</div>

<!-- about  -->





<!-- footer  -->
<?php
include_once 'includes/footer.php';
?>

<!-- footer  -->

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
<!-- Lightbox JavaScript -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/js/lightbox.min.js"></script>

<script src="assets/js/script.js"></script>
<script src="assets/js/product.js"></script>

</body>

</html>
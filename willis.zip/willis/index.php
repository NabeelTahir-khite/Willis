<?php
include_once 'includes/header.php';
?>

<!-- header / all data coming from script.js -->
<div class="container-fluid" id="slideshow"></div>
<!-- header  -->

<!-- about  -->
<div class="container about p-5">
  <!--<p class="position-title">Boatlift</p>-->
  <div class="row">
    <div class="col-lg-6 my-3 px-lg-5 d-flex justify-content-center align-items-center">
      <img src="assets/images/about.jpg" class="w-100 rounded" alt="">
    </div>
    <div class="col-lg-6 d-flex flex-column justify-content-center align-items-center my-3">

      <h3 class="title-3 mb-3">Custom Design and Engineering on all Canopy, Solar, Dock and Aqua Marine Decking with Professional Installation.</h3>

      <div class="my-4">

        <div class="row ">
          <div class="col-1 d-flex justify-content-center align-items-center"> <img src="assets/images/check.png" class="small-icon"></div>
          <div class="col-10">
            <h4 class="image-title">All Products are Designed with You in Mind,
              And Built to last even through the toughest storms</h4>
          </div>
        </div>
        <div class="row my-3">
          <div class="col-1 d-flex justify-content-center align-items-center"> <img src="assets/images/check.png" class="small-icon"></div>
          <div class="col-10">
            <h4 class="image-title">We offer Service and
              Maintenance on all our products.</h4>
          </div>
        </div>
      </div>

      <p class="text">
        At Transformation Marine , we provide solutions and the latest in technology! Our products, and services will protect your investments. You can relax and Know that We've got you Covered!
      </p>

      <p class="text">Maintaining and servicing your Boat, RV, Solar and other equipment has never been easier! Let us help you protect your Investment!</p>

    </div>





  </div>
</div>
<!-- about  -->

<!-- service  -->
<div class="service py-5">
  <div class="container">

    <div class="row">
      <h2 class="short-title"> <img src="assets/images/about-icon.png" class="small-icon" alt=""> WHAT WE DO</h2>
      <div class="col-lg-6">
        <h3 class="title">WE’RE PROVIDING QUALITY PRODUCTS AND SERVICES</h3>
      </div>
      <div class="col-lg-6">
        <p class="text">We are your one stop shop, for all your Canopy, Solar, Dock and Accessories needs.
          We help our customers find the unique “must haves” that the latest technology has to offer. Our supplier partners offer the best warranties and we back up our products with excellent services and maintenance. </p>
      </div>
    </div>

    <div class="row pt-5 service-row">

      <div class="swiper mySwiper">
        <div class="swiper-wrapper">

          <div class="swiper-slide">
            <div class="service-card">
              <img src="assets/images/custom-boatlift-service.jpg" class="w-100" alt="">
              <div class="service-content">
                <h3 class="service-title">Custom Boatlift Canopy</h3>
                <p class="service-text">We take pride in helping you protect your investments from Sun Damage with high quality storm proof canopies</p>
                <span class="read-more">Read more</span>
              </div>
            </div>
          </div>

          <div class="swiper-slide">
            <div class="service-card">
              <img src="assets/images/custom-solar-service.jpg" class="w-100" alt="">
              <div class="service-content">
                <h3 class="service-title">Custom Solar Systems</h3>
                <p class="service-text">The sun can be your most valuable ally as your source for energy! Harness the power! Residential-Commercial- Marine</p>
                <span class="read-more">Read more</span>
              </div>
            </div>
          </div>

          <div class="swiper-slide">
            <div class="service-card">
              <img src="assets/images/custom-dock-service.jpg" class="w-100" alt="">
              <div class="service-content">
                <h3 class="service-title">Custom Docks / Boat Ports</h3>
                <p class="service-text">We have everything from custom swim platforms and fish cleaning tables, to underwater lights., dock boxes and more</p>
                <span class="read-more">Read more</span>
              </div>
            </div>
          </div>

          <div class="swiper-slide">
            <div class="service-card">
              <img src="assets/images/custom-marine-service.jpg" class="w-100" alt="">
              <div class="service-content">
                <h3 class="service-title">Custom Marine Decking</h3>
                <p class="service-text">High grade non-skid resistant, foam products provide an attractive, cost-effective addon for all marine vessel needs.</p>
                <span class="read-more">Read more</span>
              </div>
            </div>
          </div>

          <div class="swiper-slide">
            <div class="service-card">
              <img src="assets/images/custom-rv-service.jpg" class="w-100" alt="">
              <div class="service-content">
                <h3 class="service-title">Custom RV Canopy</h3>
                <p class="service-text">We help you save on weather wear and tear And if you live in your RV you have to have shade! Save on Energy too!</p>
                <span class="read-more">Read more</span>
              </div>
            </div>
          </div>

          <div class="swiper-slide">
            <div class="service-card">
              <img src="assets/images/custom-dock-patio-service.jpg" class="w-100" alt="">
              <div class="service-content">
                <h3 class="service-title">Custom Deck-Patio Canopy</h3>
                <p class="service-text">Without shade most decks and patios are way too hot to enjoy. Let us help you have it “Made in The shade”!</p>
                <span class="read-more">Read more</span>
              </div>
            </div>
          </div>

          <div class="swiper-slide">
            <div class="service-card">
              <img src="assets/images/custom-carport-service.png" class="w-100" alt="">
              <div class="service-content">
                <h3 class="service-title">Custom Carport Canopy</h3>
                <p class="service-text">The sun and weather will dule the color and shine on all vehicles! We will help you Protect them!</p>
                <span class="read-more">Read more</span>
              </div>
            </div>
          </div>

          <div class="swiper-slide">
            <div class="service-card">
              <img src="assets/images/service-maintenance.png" class="w-100" alt="">
              <div class="service-content">
                <h3 class="service-title">Service and Maintenance</h3>
                <p class="service-text">We offer regular maintenance services and Detailing Take the guesswork out of these maintenance tasks and stick to a schedule by allowing our service team to do this work for you</p>
                <span class="read-more">Read more</span>
              </div>
            </div>
          </div>


        </div>
      </div>

    </div>

  </div>
</div>
<!-- service  -->

<!-- company  -->
<div class="company py-5">
  <div class="container mt-4">
    <h2 class="short-title text-center"> <img src="assets/images/about-icon.png" class="small-icon" alt=""> WHO WE ARE
    </h2>
    <h3 class="title text-center">TOP REASONS TO CHOOSE OUR COMPANY</h3>

    <div class="row py-4">
      <div class="col-lg-4">
        <div class="row my-4">
          <div class="col-sm-3 my-2 ">
            <div class="company-icon ">
              <img src="assets/images/engineers.png" style="transform: rotateY(-180deg);" alt="">
            </div>
          </div>
          <div class="col-sm-9 my-2 ps-4">
            <h3 class="company-text">Expert Engineers</h3>
            <p class="company-content">Our professional staff handles everything from the initial contact, to
              production to installation to maintenance. We got you covered</p>
          </div>
        </div>
        <div class="row my-4">
          <div class="col-sm-3 my-2 ">
            <div class="company-icon">
              <img src="assets/images/insured.png" alt="">
            </div>
          </div>
          <div class="col-sm-9 my-2 ps-4">
            <h3 class="company-text">Fully Insured</h3>
            <p class="company-content">We take pride in our services and are fully insured in case and accident
              happens or there is an unforeseen issue.</p>
          </div>
        </div>
      </div>
      <div class="col-lg-4 d-flex justify-content-center align-items-center">
        <img src="assets/images/banner2.jpg" class="company-image" alt="">
      </div>
      <div class="col-lg-4">

        <div class="row my-4">
          <div class="col-sm-9 text-start my-2 text-sm-end order-2 order-sm-1">
            <h3 class="company-text">Quality Material </h3>
            <p class="company-content">We only offer top quality products and work with the top suppliers. We offer
              the latest technology in everything we do </p>
          </div>
          <div class="col-sm-3 text-start my-2 text-sm-end order-1 order-sm-2">
            <div class="company-icon company-icon1">
              <img src="assets/images/quality.png" style="transform: rotateY(-180deg);" alt="">
            </div>
          </div>
        </div>
        <div class="row my-4">
          <div class="col-sm-9 text-start my-2 text-sm-end order-2 order-sm-1">
            <h3 class="company-text">Warranty</h3>
            <p class="company-content">All of our products come with a manufacturer warranty that is backed by
              excellent service.</p>
          </div>
          <div class="col-sm-3 text-start my-2 text-sm-end order-1 order-sm-2">
            <div class="company-icon">
              <img src="assets/images/warranty.png" alt="">
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row justify-content-center ps-2">
      <div class="col-lg-5">
        <div class="row"> 
          <div class="col-sm-2 my-2 d-flex justify-content-start justify-content-sm-end px-0">
            <div class="company-icon">
              <img src="assets/images/engineers.png" style="transform: rotateY(-180deg);" alt="">
            </div>
          </div>
          <div class="col-sm-10 my-2 ">
            <h3 class="company-text">Maintenance and Service</h3>
            <p class="company-content">We offer a scheduled maintenance agreement on most of our products that is backed by excellent service.</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- company  -->

<!-- project -->
<div class="container-fluid project py-5">
  <h2 class="short-title text-center"> <img src="assets/images/about-icon.png" class="small-icon" alt=""> COMPANY
    CREDIBILITY</h2>
  <h3 class="title text-center">EXPLORE A FEW OF OUR PROJECTS FOR YOUR INSPIRATION</h3>

  <div class="row px-2 mt-4 justify-content-center">

    <div class="col-md-4 col-sm-6 my-2">
      <div class="project-img">
        <a href="assets/images/project1.jpg" data-lightbox="gallery">
          <img src="assets/images/project1.jpg" alt="">
        </a>
      </div>
    </div>
    <div class="col-md-4 col-sm-6 my-2">
      <div class="project-img">
        <a href="assets/images/project2.jpg" data-lightbox="gallery">
          <img src="assets/images/project2.jpg" alt="">
        </a>
      </div>
    </div>
    <div class="col-md-4 col-sm-6 my-2">
      <div class="project-img">
        <a href="assets/images/project3.jpg" data-lightbox="gallery">
          <img src="assets/images/project4.jpg" alt="">
        </a>
      </div>
    </div>
    <div class="col-md-4 col-sm-6 my-2">
      <div class="project-img">
        <a href="assets/images/project4.jpg" data-lightbox="gallery">
          <img src="assets/images/project4.jpg" alt="">
        </a>
      </div>
    </div>
    <div class="col-md-4 col-sm-6 my-2">
      <div class="project-img">
        <a href="assets/images/project5.jpg" data-lightbox="gallery">
          <img src="assets/images/project5.jpg" alt="">
        </a>
      </div>
    </div>
    <div class="col-md-4 col-sm-6 my-2">
      <div class="project-img">
        <a href="assets/images/project6.png" data-lightbox="gallery">
          <img src="assets/images/project6.png" alt="">
        </a>
      </div>
    </div>
    <div class="col-md-4 col-sm-6 my-2">
      <div class="project-img">
        <a href="assets/images/project7.jpg" data-lightbox="gallery">
          <img src="assets/images/project7.jpg" alt="">
        </a>
      </div>
    </div>
    <div class="col-md-4 col-sm-6 my-2">
      <div class="project-img">
        <a href="assets/images/project8.jpg" data-lightbox="gallery">
          <img src="assets/images/project8.jpg" alt="">
        </a>
      </div>
    </div>
    <div class="col-md-4 col-sm-6 my-2">
      <div class="project-img">
        <a href="assets/images/project9.jpg" data-lightbox="gallery">
          <img src="assets/images/project9.jpg" alt="">
        </a>
      </div>
    </div>
    <div class="col-md-4 col-sm-6 my-2">
      <div class="project-img">
        <a href="assets/images/project10.jpg" data-lightbox="gallery">
          <img src="assets/images/project10.jpg" alt="">
        </a>
      </div>
    </div>
    <div class="col-md-4 col-sm-6 my-2">
      <div class="project-img">
        <a href="assets/images/project11.jpg" data-lightbox="gallery">
          <img src="assets/images/project11.jpg" alt="">
        </a>
      </div>
    </div>
    <div class="col-md-4 col-sm-6 my-2">
      <div class="project-img">
        <a href="assets/images/project12.jpg" data-lightbox="gallery">
          <img src="assets/images/project12.jpg" alt="">
        </a>
      </div>
    </div>
    <div class="col-md-4 col-sm-6 my-2">
      <div class="project-img">
        <a href="assets/images/project13.jpg" data-lightbox="gallery">
          <img src="assets/images/project13.jpg" alt="">
        </a>
      </div>
    </div>
    <div class="col-md-4 col-sm-6 my-2">
      <div class="project-img">
        <a href="assets/images/project14.jpg" data-lightbox="gallery">
          <img src="assets/images/project14.jpg" alt="">
        </a>
      </div>
    </div>
    <div class="col-md-4 col-sm-6 my-2">
      <div class="project-img">
        <a href="assets/images/project15.jpg" data-lightbox="gallery">
          <img src="assets/images/project15.jpg" alt="">
        </a>
      </div>
    </div>
    <div class="col-md-4 col-sm-6 my-2">
      <div class="project-img">
        <a href="assets/images/project16.jpg" data-lightbox="gallery">
          <img src="assets/images/project16.jpg" alt="">
        </a>
      </div>
    </div>
    <div class="col-md-4 col-sm-6 my-2">
      <div class="project-img">
        <a href="assets/images/project17.jpg" data-lightbox="gallery">
          <img src="assets/images/project17.jpg" alt="">
        </a>
      </div>
    </div>
    <div class="col-md-4 col-sm-6 my-2">
      <div class="project-img">
        <a href="assets/images/project18.jpg" data-lightbox="gallery">
          <img src="assets/images/project18.jpg" alt="">
        </a>
      </div>
    </div>
    <div class="col-md-4 col-sm-6 my-2">
      <div class="project-img">
        <a href="assets/images/project19.jpg" data-lightbox="gallery">
          <img src="assets/images/project19.jpg" alt="">
        </a>
      </div>
    </div>
    <div class="col-md-4 col-sm-6 my-2">
      <div class="project-img">
        <a href="assets/images/project20.jpg" data-lightbox="gallery">
          <img src="assets/images/project20.jpg" alt="">
        </a>
      </div>
    </div>
    <div class="col-md-4 col-sm-6 my-2">
      <div class="project-img">
        <a href="assets/images/project21.jpg" data-lightbox="gallery">
          <img src="assets/images/project21.jpg" alt="">
        </a>
      </div>
    </div>
    <div class="col-md-4 col-sm-6 my-2">
      <div class="project-img">
        <a href="assets/images/project22.jpg" data-lightbox="gallery">
          <img src="assets/images/project22.jpg" alt="">
        </a>
      </div>
    </div>
    <div class="col-md-4 col-sm-6 my-2">
      <div class="project-img">
        <a href="assets/images/project23.jpg" data-lightbox="gallery">
          <img src="assets/images/project23.jpg" alt="">
        </a>
      </div>
    </div>
    <div class="col-md-4 col-sm-6 my-2">
      <div class="project-img">
        <a href="assets/images/project25.jpg" data-lightbox="gallery">
          <img src="assets/images/project25.jpg" alt="">
        </a>
      </div>
    </div>
    <div class="col-md-4 col-sm-6 my-2">
      <div class="project-img">
        <a href="assets/images/project26.jpg" data-lightbox="gallery">
          <img src="assets/images/project26.jpg" alt="">
        </a>
      </div>
    </div>
 
    <div class="col-md-4 col-sm-6 my-2">
      <div class="project-img">
        <a href="assets/images/project28.jpg" data-lightbox="gallery">
          <img src="assets/images/project28.jpg" alt="">
        </a>
      </div>
    </div>
    <div class="col-md-4 col-sm-6 my-2">
      <div class="project-img">
        <a href="assets/images/project29.jpg" data-lightbox="gallery">
          <img src="assets/images/project29.jpg" alt="">
        </a>
      </div>
    </div>
    <div class="col-md-4 col-sm-6 my-2">
      <div class="project-img">
        <a href="assets/images/project30.jpg" data-lightbox="gallery">
          <img src="assets/images/project30.jpg" alt="">
        </a>
      </div>
    </div>
 


  </div>

</div>
<!-- project -->


<!-- footer  -->
<?php
include_once 'includes/footer.php';
?>

<!-- footer  -->


<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
<!-- Lightbox JavaScript -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/js/lightbox.min.js"></script>

<script src="assets/js/script.js"></script>

<script src="assets/js/banner.js"> </script>

<!-- Swiper JS -->
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>


<script>
  document.addEventListener("DOMContentLoaded", function() {
    // Initialize Swiper
    var swiper = new Swiper('.mySwiper', {
      slidesPerView: 4,
      spaceBetween: 30,
      loop: true, // Enable looping
      autoplay: {
        delay: 2000, // Auto-run every 2 seconds
        disableOnInteraction: false, // Continue autoplay after user interaction
      },
      navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
      },
      pagination: {
        el: '.swiper-pagination',
        clickable: true,
      },
      breakpoints: {
        // when window width is <= 320px
        320: {
          slidesPerView: 1,
          spaceBetween: 10
        },
        // when window width is <= 480px
        480: {
          slidesPerView: 1,
          spaceBetween: 20
        },
        // when window width is <= 640px
        640: {
          slidesPerView: 2,
          spaceBetween: 20
        },
        // when window width is <= 768px
        768: {
          slidesPerView: 2,
          spaceBetween: 20
        },
        // when window width is <= 1024px
        1024: {
          slidesPerView: 3,
          spaceBetween: 30
        },
        // when window width is <= 1200px
        1200: {
          slidesPerView: 4,
          spaceBetween: 30
        }
      }
    });

    // Stop autoplay on hover and restart on mouse leave
    const swiperContainer = document.querySelector('.swiper');
    swiperContainer.addEventListener('mouseenter', () => {
      swiper.autoplay.stop();
    });
    swiperContainer.addEventListener('mouseleave', () => {
      swiper.autoplay.start();
    });

    // Read more functionality
    var readMoreButtons = document.querySelectorAll('.read-more');

    readMoreButtons.forEach(function(button) {
      button.addEventListener('click', function() {
        var content = this.previousElementSibling;
        content.classList.toggle('expanded');
        this.textContent = content.classList.contains('expanded') ? 'Read less' : 'Read more';
      });
    });
  });
</script>

</body>

</html>
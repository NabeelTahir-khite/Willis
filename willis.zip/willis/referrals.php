<?php 
include_once 'includes/header.php';
?>

<!-- navbar  -->

    <!-- inner banner  -->

    <div class="container-fluid inner-banner" style="background-image: url('assets/images/referrals-banner.jpg');"></div>

    <!-- inner banner  -->


    <!-- project -->
    <div class="container-fluid top-project py-5 ">
        <div class="row">
            <div class="col-lg-6 my-3 d-flex justify-content-center flex-column align-items-center px-lg-5">
                <img src="assets/images/referrals-about1.png" class="w-100 rounded" alt="">
                <img src="assets/images/referrals-about2.png" class="w-100 rounded mt-3" alt="">
            </div>
            <div class="col-lg-6 my-3 px-lg-5">
                <h2 class="short-title text-white"> <img src="assets/images/about-icon.png" class="small-icon-1" alt="">
                    REFERRALS</h2>
                <h3 class="title-3 text-white">We would like to Reward all our valuable customers for their referral business and word of mouth endorsements, testimonials.</h3>

                <div class="my-4 ">
                    <p class="para2 text-white">We are happy and excited to offer our satisfied customers a referral incentive program that rewards you for sending us business. You will receive rewards for referring neighbors, friends, family and anyone else that buys one of our canopy and or solar systems. The Vacation Store and Vacay Saver platform gives you access to anything you want to do fun! Its like having access to a full-service instant access Concierge  on your phone!
                        You can  book Hotels, Rental cars, Activities, VIP Services, Live shows ,Events and Dinning at highly discounted wholesale rates with “VacayCredits” or “ VacayCash” you earn by referring us business. Both currencies can be used for everything on the platform. Most importantly, This is a system that is easily accessed and user-friendly. We are offering VCredits for every Referral that you send.</p>
                    <p class="para2 text-white">Make sure you email us a list and or make sure your friend or family mentions your name, address and or email and phone number when they contact us. We make sure you get your credits as quickly as possible! Its our way of saying Thank you again for your valuable word of mouth advertising!</p>
                    <p class="para2 text-white">Have someone in mind who you think would be the perfect fit for a Canopy and or Solar System ? Submit their name address , phone number and email  to <a href="mailto:transformationmarine@gmail.com" class="text-white">transformationmarine@gmail.com</a> and you can receive up to a $1500.00 referral VCredits.</p>

               
                </div>
            </div>

        </div>

  

    </div>
    <!-- project -->


    <!-- footer  -->
    <?php 
include_once 'includes/footer.php';
?>

  <!-- footer  -->

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"
        integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <!-- Lightbox JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/js/lightbox.min.js"></script>

    <script src="assets/js/script.js"></script>

</body>

</html>
<footer class="container-fluid footer">

    <div class="row border-bottom border-top footer-top">
        <div class="col-lg-3 col-md-6 col-sm-5 footer-1 px-0">
            <img src="assets/images/footer-img2.jpg" class="" alt="">
        </div>
        <div class="col-lg-2 col-md-3 col-sm-4 d-flex justify-content-center align-items-center px-0 footer-2">
            <img src="assets/images/satisfaction.png" alt="">
        </div>
        <div class="col-lg-2 col-md-3 col-sm-3 d-flex  justify-content-center align-items-center px-0">
            <a href="contact" class="getBtn p-3">Get Quote Now</a>
        </div>
    </div>


    <div class="container footer-content pt-5">
        <div class="row pb-3">

            <div class="col-lg-4 col-md-6 mt-3 footer-first">
                <img src="assets/images/transformation-marine-logo.png" class="logo" alt="">
                <p class="text text-white my-3"> Providing Canopy, Solar and Service
                    Solutions to all Residential Commercial and Marine applications. We are focused on customer satisfaction and
                    high-quality products and services.
                </p>

                <div class="social-icons">
                    <a href="#">
                        <i class="fa-brands fa-twitter"></i>
                    </a>
                    <a href="#">
                        <i class="fa-brands fa-facebook"></i>
                    </a>
                    <a href="#">
                        <i class="fa-brands fa-pinterest-p"></i>
                    </a>
                    <a href="#">
                        <i class="fa-brands fa-instagram"></i>
                    </a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 mt-3">
                <div class="row">
                    <div class="col-sm-6 border-start">
                        <h4 class="footer-title">Explore</h4>
                        <div class="footer-item">
                            <a href="index">Home</a>
                            <a href="#">Services</a>
                            <a href="#">Canopy</a>
                            <a href="#">Solar</a>
                            <a href="#">Store</a>
                            <a href="referrals">Referrals</a>
                        </div>
                    </div>
                    <div class="col-sm-6 border-start border-end">
                        <h4 class="footer-title">Menu</h4>
                        <div class="footer-item">
                            
                            <a href="become-an-affiliate">Affiliates</a>
                            <a href="become-a-supplier">Suppliers</a>
                            <a href="testimonials">Testimonials</a>
                            <a href="team-opportunities">Team Opportunities</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 mt-3">
                <h4 class="footer-title">Contact</h4>
                <div class="footer-address">
                    <p><i class="fa-solid fa-phone"></i> <span><a href="tel:8439024469">843-902-4469</a></span></p>
                    <p><i class="fa-solid fa-envelope"></i> <span><a href="mailto:Info@transformationmarine.com">Info@transformationmarine.com</a></span></p>
                    <p><i class="fa-solid fa-location-dot"></i> <span>
                            1000 2nd Ave S.
                            Suite 300
                            NMB S.C. 29582

                        </span></p>
                    <p><i class="fa-regular fa-clock"></i> <span>Mon to Sat: 09:00 am to 05:00 pm</span></p>
                </div>
            </div>
        </div>

        <div class="copyright py-2">
            <p class="m-0">&copy; All Copyright 2024</p>
        </div>
    </div>



</footer>
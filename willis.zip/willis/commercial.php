<?php
include_once 'includes/header.php';
?>

<!-- navbar  -->

<!-- inner banner  -->

<div class="container-fluid inner-banner" style="background-image: url('assets/images/commercial-banner.jpg');"></div>

<!-- inner banner  -->

<!-- about  -->
<div class="container about p-5">
    <div class="row ">
        <div class="col-lg-6 my-3 d-flex justify-content-center flex-column px-lg-5">
            <img src="assets/images/commercial-about.png" class="w-100 rounded" alt="">

            
        </div>
        <div class="col-lg-6 my-3 px-lg-5">
            <h2 class="short-title"> <img src="assets/images/about-icon.png" class="small-icon-1" alt="">
                BRIGHTEN YOUR WORKPLACE WITH SOLAR</h2>

            <h3 class="title-3">SMART SOLUTION FOR CLEAN ENERGY</h3>


            <div class="my-4">
                <p class="para1">Solar Energy is a plentiful, reliable and renewable energy source and is also the cleanest type of energy known to man since it is pollution free and contributes to the reduction of a country’s carbon emissions. Commercial buildings (offices and other business organizations) depends on electricity for most of their energy consumption needs and the consumption of power in an office building during the daytime is much higher which makes them ideally suited to install solar panels and dozens of state and central tax rebate and credit opportunities are available for rooftop-solar systems for the ones interested in using solar energy in commercial buildings.</p>



            </div>
        </div>
        
        <p class="para1 mt-3">Offices and Businesses can use solar panels and solar thermal panels for a variety of uses including pre-heating ventilation air, water heating, solar cooling and lighting and electricity. We provide a better solution for your corporate office where you can produce your own electricity for the daily working.</p>
            <p class="para1">Having a solar installation at your office can help you with many benefits: </p>
            <p class="para1">Reduces the Operating Cost.</p>
            <p class="para1">Good Return on Investment.</p>
            <p class="para1"> Maintenance free and Reliable.</p>
            <p class="para1">Eco-friendly to the nature.</p>


    </div>


</div>
<!-- about  -->

<!-- project -->
<div class="container-fluid project py-5">
    <div class="project-title">
            <h2 class="title text-center">POWER YOUR BUSINESS WITH SOLAR ENERGY AND SAVE BIG</h2>
         
        </div>


    <div class="row justify-content-center mt-4">

        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/commercial1.jpg" data-lightbox="gallery">
                    <img src="assets/images/commercial1.jpg" alt="">
                </a>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/commercial2.jpg" data-lightbox="gallery">
                    <img src="assets/images/commercial2.jpg" alt="">
                </a>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/commercial3.png" data-lightbox="gallery">
                    <img src="assets/images/commercial3.png" alt="">
                </a>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/commercial4.jpg" data-lightbox="gallery">
                    <img src="assets/images/commercial4.jpg" alt="">
                </a>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/commercial5.jpg" data-lightbox="gallery">
                    <img src="assets/images/commercial5.jpg" alt="">
                </a>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/commercial6.jpg" data-lightbox="gallery">
                    <img src="assets/images/commercial6.jpg" alt="">
                </a>
            </div>
        </div>



    </div>

</div>
<!-- project -->


<!-- footer  -->
<?php 
include_once 'includes/footer.php';
?>

<!-- footer  -->

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
<!-- Lightbox JavaScript -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/js/lightbox.min.js"></script>

<script src="assets/js/script.js"></script>

</body>

</html>
<?php
include_once 'includes/header.php';
?>

<!-- navbar  -->

<!-- inner banner  -->

<div class="container-fluid inner-banner" style="background-image: url('assets/images/marina-banner.jpg');"></div>

<!-- inner banner  -->

<!-- about  -->
<div class="container about p-5">
    <div class="row">
        <div class="col-lg-6 my-3 d-flex justify-content-center align-items-center px-lg-5">
            <img src="assets/images/marina-about.jpg" class="w-100 rounded" height="300" alt="">
        </div>
        <div class="col-lg-6 my-3 d-flex flex-column align-items-start justify-content-center px-lg-5">
            <h2 class="short-title"> <img src="assets/images/about-icon.png" class="small-icon-1" alt="">
                COMMERCIAL WORK CENTERS</h2>
            <h3 class="title-3">Custom Marina Design Covers Available</h3>

            <div class="mt-4">
                <p class="para1">Planning and Manufacturing Large scale projects exceeding 50 cover installs as well as larger scaled installs is also our specialty.
                    We take special interest in your marina projects. Starting with a site visit and measurements we custom build each cover to fit your specific needs.</p>


            </div>
        </div>

    </div>
</div>
<!-- about  -->

<!-- project -->
<div class="container-fluid project py-5">

        <h2 class="title text-center">CUSTOM MARINA DESIGN COVERS</h2>
  

    <div class="row justify-content-center mt-4">

        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/marina1.jpg" data-lightbox="gallery">
                    <img src="assets/images/marina1.jpg" alt="">
                </a>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/marina2.jpg" data-lightbox="gallery">
                    <img src="assets/images/marina2.jpg" alt="">
                </a>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/marina3.jpg" data-lightbox="gallery">
                    <img src="assets/images/marina3.jpg" alt="">
                </a>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/marina4.jpg" data-lightbox="gallery">
                    <img src="assets/images/marina4.jpg" alt="">
                </a>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/marina5.jpg" data-lightbox="gallery">
                    <img src="assets/images/marina5.jpg" alt="">
                </a>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/marina6.jpg" data-lightbox="gallery">
                    <img src="assets/images/marina6.jpg" alt="">
                </a>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/marina7.png" data-lightbox="gallery">
                    <img src="assets/images/marina7.png" alt="">
                </a>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/marina8.jpg" data-lightbox="gallery">
                    <img src="assets/images/marina8.jpg" alt="">
                </a>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/marina9.jpg" data-lightbox="gallery">
                    <img src="assets/images/marina9.jpg" alt="">
                </a>
            </div>
        </div>


    </div>

</div>
<!-- project -->


<!-- footer  -->
<?php 
include_once 'includes/footer.php';
?>

<!-- footer  -->

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
<!-- Lightbox JavaScript -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/js/lightbox.min.js"></script>

<script src="assets/js/script.js"></script>

</body>

</html>
<?php

session_start();
require 'PHPMailer/PHPMailer.php';
require 'PHPMailer/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $city = $_POST['city'];
    $zip = $_POST['zip'];
    $about = $_POST['about'];
    $interest = $_POST['interest'];
    $messageText = $_POST['message'];

    $message = "
        <h2>Contact Form Submission</h2>
        <p><strong>First Name:</strong> $fname</p>
        <p><strong>Last Name:</strong> $lname</p>
        <p><strong>Email:</strong> $email</p>
        <p><strong>Phone:</strong> $phone</p>
        <p><strong>Address:</strong> $address</p>
        <p><strong>City:</strong> $city</p>
        <p><strong>Zip:</strong> $zip</p>
        <p><strong>How did you hear about us?:</strong> $about</p>
        <p><strong>What is your primary interest in?:</strong> $interest</p>
        <p><strong>Message:</strong> $messageText</p>
    ";

    $mail = new PHPMailer(true);

    try {
        //Server settings
        $mail->isSMTP();
        $mail->Host       = 'transformationmarine.com'; // SMTP server
        $mail->SMTPAuth   = true;
        $mail->Username   = 'info@transformationmarine.com'; // SMTP username
        $mail->Password   = 'Admin@marine'; // SMTP password
        $mail->SMTPSecure = 'ssl'; //Enable implicit TLS encryption
        $mail->Port       = 465;

        //Recipients
        $mail->setFrom('info@transformationmarine.com', 'Transformation Marine');
        $mail->addAddress('info@transformationmarine.com'); // Add your own address to receive the email

        //Attachments
        if (!empty($_FILES['file']['name'])) {
            $file_tmp_name = $_FILES['file']['tmp_name'];
            $file_name = $_FILES['file']['name'];
            $mail->addAttachment($file_tmp_name, $file_name);
        }

        //Content
        $mail->isHTML(true);
        $mail->Subject = 'Form Submission';
        $mail->Body    = $message;

        $mail->send();
        $_SESSION['success']= "Thank You For Contacting Us!";
       
    } catch (Exception $e) {
        $_SESSION['error']= "Something went wrong. Please try again.";
    }
        header("location: contact");
}
?>

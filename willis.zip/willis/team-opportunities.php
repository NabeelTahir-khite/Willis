<?php
include_once 'includes/header.php';
?>

<!-- navbar  -->

<!-- inner banner  -->

<div class="container-fluid inner-banner" style="background-image: url('assets/images/team-opportunities-banner.png');"></div>

<!-- inner banner  -->

<!-- about  -->
<div class="container about p-5">
    <div class="row">
        <div class="col-lg-6 my-3 d-flex justify-content-center align-items-center px-lg-5">
            <img src="assets/images/team-opportunities-about1.jpg" class="w-100 rounded" height="300" alt="">
        </div>
        <div class="col-lg-6 my-3 px-lg-5 d-flex flex-column justify-content-center align-items-start">

            <div class="my-4">
                <h3 class="title-3">WE ARE HIRING TEAM PLAYERS IN SEVERAL NEW MARKETS</h3>
                <p class="para1">Are you a team player? We are always interested in people that are looking to grow with us. We take pride in our products and services and we believe that good service paired together with the best products and latest technology creates an environment where everyone Wins! We offer competitive pay along with continued training, If you are interested in a Position in our company fill out the contact form below.</p>


            </div>
        </div>

    </div>

    <div class="team-services">

        <div class="row my-3">
            <div class="col-lg-3 col-md-4 d-flex justify-content-center mt-2">
                <img src="assets/images/team-opportunities-install.jpg" alt="">
            </div>
            <div class="col-lg-9 col-md-8  d-flex justify-content-center align-items-center mt-2">
                <p class="para1">Install Technicians – {Experienced And Training Provided}
                    Must not be afraid of heights!!!!!! Must have transportation, Must have your own tools and be able to climb and carry up to 50lbs. Must be physically fit and know how to read a tape measure. Must know how to work a ladder and cannot be scared of heights or getting wet.</p>
            </div>
        </div>
        <div class="row my-3">
            <div class="col-lg-3 col-md-4 d-flex justify-content-center mt-2">
                <img src="assets/images/team-opportunities-mechanic.jpg" alt="">
            </div>
            <div class="col-lg-9 col-md-8  d-flex justify-content-center align-items-center mt-2">
                <p class="para1">Mechanic-Service Technicians – {Experienced Only}
                    Must Have Transportation, your own tools and mechanical skills along with good understanding of marine outboard, Deisel/Gas inboard motors and RVs. Any Mechanic Certifications are a plus.</p>
            </div>
        </div>
        <div class="row my-3">
            <div class="col-lg-3 col-md-4 d-flex justify-content-center mt-2">
                <img src="assets/images/team-opportunities-detailers.jpg" alt="">
            </div>
            <div class="col-lg-9 col-md-8  d-flex justify-content-center align-items-center mt-2">
                <p class="para1">Detailer Technicians- {Experienced And Or Training Provided}
                    Must Have transportation and excellent attention to detail! Be physically fit and like to work outside. We are always looking for entry level detailers that are quick learners, we offer detailing , buff, wax, on boats, RVs and some automobiles.</p>
            </div>
        </div>
        <div class="row my-3">
            <div class="col-lg-3 col-md-4 d-flex justify-content-center mt-2">
                <img src="assets/images/team-opportunities-detailers1.jpg" alt="">
            </div>
            <div class="col-lg-9 col-md-8  d-flex justify-content-center align-items-center mt-2">
                <p class="para1">Detailer Technicians- {Experienced /Training Provided}
                    Must Have transportation and excellent attention to detail! Be physically fit and like to work outside. We are always looking for entry level detailers that are quick learners, we offer detailing , buff, wax, on boats, RVs and some automobiles.</p>
            </div>
        </div>
        <div class="row my-3">
            <div class="col-lg-3 col-md-4 d-flex justify-content-center mt-2">
                <img src="assets/images/team-opportunities-appointment.jpg" alt="">
            </div>
            <div class="col-lg-9 col-md-8  d-flex justify-content-center align-items-center mt-2">
                <p class="para1">Appointment Setters/Door Knockers – {Experienced/Training Provided}
                    Must have your own transportation, Must be a self Starter and must be proficient with Google Calander. Do you like helping others? Do you enjoy talking to people face to face? If you are looking for a position to learn and grow don’t hesitate to contact us!</p>
            </div>
        </div>
        <div class="row my-3">
            <div class="col-lg-3 col-md-4 d-flex justify-content-center mt-2">
                <img src="assets/images/team-opportunities-sales.jpg" alt="">
            </div>
            <div class="col-lg-9 col-md-8  d-flex justify-content-center align-items-center mt-2">
                <p class="para1">Sales Agents – {Experienced Only}
                    We have several Dealerships, and we supply all leads and appointments for several products and services. If you are a self starter and can work our referral program that is a plus. Do you have sales experience? Do you have a history of offering excellent service to your customers? Are you familiar with in-home sales? Do you have what it takes to learn a proven system and be a team player? Are you looking for a long term career offering top quality products and services and building a customer and referral base that continues to grow year after year.
                </p>
            </div>
        </div>
        <div class="row my-3">
            <div class="col-lg-3 col-md-4 d-flex justify-content-center mt-2">
                <img src="assets/images/team-opportunities-customer.jpg" alt="">
            </div>
            <div class="col-lg-9 col-md-8  d-flex justify-content-center align-items-center mt-2">
                <p class="para1">Customer Service- {Experienced /Training Provided}
                    Are you a detailed person? Do you like helping others? Do you enjoy talking to people face to face or on the phone? Are you proficient online and or with google calendar and or Microsoft office? We are always interested in people that have what it takes to go the extra mile for our customers. If you are looking for a position to learn and grow don’t hesitate to contact us!</p>
            </div>
        </div>

        <p class="para1">If you are interested in becoming part of our team  or have any questions let us know!</p>
        <p class="para1">Please fill out a contact us  form and provide your resume for consideration!</p>
        <p class="para1">Thank You</p>
        <p class="para1">Team Transformation </p>
        </div>


</div>
<!-- about  -->


<!-- project -->
<div class="container-fluid project py-5">
    
    <div class="project-title">
            <h2 class="title text-center">WE WORK TOGETHER TO DELIVER THE HIGHEST QAULITY PRODUCTS AND SERVICES AVAILABLE</h2>
            
        </div>

    <div class="row justify-content-center mt-4">

        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/team-opportunities-1.jpg" data-lightbox="gallery">
                    <img src="assets/images/team-opportunities-1.jpg" alt="">
                </a>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/team-opportunities-2.jpg" data-lightbox="gallery">
                    <img src="assets/images/team-opportunities-2.jpg" alt="">
                </a>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/team-opportunities-3.jpg" data-lightbox="gallery">
                    <img src="assets/images/team-opportunities-3.jpg" alt="">
                </a>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/team-opportunities-4.jpg" data-lightbox="gallery">
                    <img src="assets/images/team-opportunities-4.jpg" alt="">
                </a>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/team-opportunities-5.jpg" data-lightbox="gallery">
                    <img src="assets/images/team-opportunities-5.jpg" alt="">
                </a>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/team-opportunities-6.jpg" data-lightbox="gallery">
                    <img src="assets/images/team-opportunities-6.jpg" alt="">
                </a>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/team-opportunities-7.jpg" data-lightbox="gallery">
                    <img src="assets/images/team-opportunities-7.jpg" alt="">
                </a>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/team-opportunities-8.jpg" data-lightbox="gallery">
                    <img src="assets/images/team-opportunities-8.jpg" alt="">
                </a>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 my-2">
            <div class="project-img">
                <a href="assets/images/team-opportunities-9.jpg" data-lightbox="gallery">
                    <img src="assets/images/team-opportunities-9.jpg" alt="">
                </a>
            </div>
        </div>





    </div>

</div>
<!-- project -->


<!-- footer  -->
<?php
include_once 'includes/footer.php';
?>

<!-- footer  -->

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
<!-- Lightbox JavaScript -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/js/lightbox.min.js"></script>

<script src="assets/js/script.js"></script>

</body>

</html>
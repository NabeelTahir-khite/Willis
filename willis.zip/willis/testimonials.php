<?php
include_once 'includes/header.php';
?>

<!-- navbar  -->

<!-- inner banner  -->

<div class="container-fluid inner-banner" style="background-image: url('assets/images/testimonials-banner.jpg');">
</div>

<!-- inner banner  -->

<!-- project -->
<div class="container-fluid project py-5">
    <div class="container">

        <h2 class="short-title text-white"> <img src="assets/images/about-icon.png" class="small-icon-1" alt="">
            TESTIMONIALS</h2>

   <div class="row my-2">
            <div class="col-md-7">
                <div class="testimonial">
                    <blockquote>
                        We are very pleased with the product, service and installation of our boat lift canopy. Our
                        sales rep, Tim was very professional and knowledgeable. Service was provided as promised
                        within the 2 to 3 week time frame and the installers completed the job in under 3 hours.
                    </blockquote>
                    <div></div>
                    <p>
                        <img src="assets/images/testimonial1.jpg" width="60px" height="60px" class="rounded-circle me-2" alt=""> Denise M.
                    </p>
                </div>
            </div>
        </div>
        <div class="row my-2">
            <div class="col-md-7 offset-md-5">
                <div class="testimonial">
                    <blockquote>
                        We love this company. We were looking for a while to get a cover done on our elevator boat lift. They came out promptly to do the estimate, did a great custom design, troubleshot all issues, and installed very quickly. Price was reasonable and the work was top notch. We highly recommend this company. We could not have been happier! Thank you, Waterway!!
                    </blockquote>
                    <div></div>
                    <p>
                        <img src="assets/images/testimonial2.jpg" width="60px" height="60px" class="rounded-circle me-2" alt="">
                        Carolyn B.
                    </p>
                </div>
            </div>
        </div>
        <div class="row my-2">
            <div class="col-md-7">
                <div class="testimonial">
                    <blockquote>
                        We had a new cover installed on our lift a couple of weeks ago in St James City. Install was completed 4 business days after we ordered it and the work completed in 2-hrs. The design is perfect for our boat and the cover looks great. Highly recommended!
                    </blockquote>
                    <div></div>
                    <p>
                        <img src="assets/images/testimonial3.jpg" width="60px" height="60px" class="rounded-circle me-2" alt="">
                        Michael P
                    </p>
                </div>
            </div>
        </div>
        <div class="row my-2">
            <div class="col-md-7 offset-md-5">
                <div class="testimonial">
                    <blockquote>
                        <h6>Hydro-Shield</h6>
                        Bought it for my Yamaha 250 SHO because I was impressed with the one my neighbor has. Going on my project boat and can't wait to put it in the water.
                        <br><br>
                        <h6>Very happy</h6>
                    </blockquote>
                    <div></div>
                    <p>
                        <img src="assets/images/testimonial1.jpg" width="60px" height="60px" class="rounded-circle me-2" alt=""> Douglas
                    </p>
                </div>
            </div>
        </div>
        <div class="row my-2">
            <div class="col-md-7 ">
                <div class="testimonial">
                    <blockquote>
                        <h6>Hydro-Shield</h6>
                        I bought this unit and was a little scared about drilling holes I wanted to be right the first time. I actually got on the phone with the owner. He walked me right through it. And it works perfect. I was going to go ahead and list his home phone number. Haha
                        <br><br>
                        <h6>Great so far</h6>
                    </blockquote>
                    <div></div>
                    <p>
                        <img src="assets/images/testimonial2.jpg" width="60px" height="60px" class="rounded-circle me-2" alt="">
                        Les Rogge
                    </p>
                </div>
            </div>
        </div>
        <div class="row my-2">
            <div class="col-md-7 offset-md-5">
                <div class="testimonial">
                    <blockquote>
                        <h6>Hydro-Shield</h6>
                    I have a Worldcat 255DC which is known to porpoise at certain speeds. The fins seemed to have really helped stabilize the boat at these higher speeds. The do not appear to have generated any noticeable drag. I also live on a shallow creek with some obstructions and lots of wildlife including Manatees so this was also a reason for purchase. The installation process was not difficult but the instructions showing using a ruler for alignment were a bit bizarre and seem prone to increase error depending on how/where you hold the ruler.
                    <br><br>
                    <h6>LOVE IT</h6>
                    </blockquote>
                    <div></div>
                    <p>
                        <img src="assets/images/testimonial3.jpg" width="60px" height="60px" class="rounded-circle me-2" alt="">
                       Bryan Jones
                    </p>
                </div>
            </div>
        </div>

    </div>
    
    <div class="row justify-content-center mt-4">
            

            <div class="col-md-4 col-sm-6 my-2">
                <div class="project-img">
                    <a href="assets/images/testimonials1.jpg" data-lightbox="gallery">
                        <img src="assets/images/testimonials1.jpg" alt="">
                    </a>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 my-2">
                <div class="project-img">
                    <a href="assets/images/testimonials2.jpg" data-lightbox="gallery">
                        <img src="assets/images/testimonials2.jpg" alt="">
                    </a>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 my-2">
                <div class="project-img">
                    <a href="assets/images/testimonials3.jpg" data-lightbox="gallery">
                        <img src="assets/images/testimonials3.jpg" alt="">
                    </a>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 my-2">
                <div class="project-img">
                    <a href="assets/images/testimonials4.jpg" data-lightbox="gallery">
                        <img src="assets/images/testimonials4.jpg" alt="">
                    </a>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 my-2">
                <div class="project-img">
                    <a href="assets/images/testimonials5.jpg" data-lightbox="gallery">
                        <img src="assets/images/testimonials5.jpg" alt="">
                    </a>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 my-2">
                <div class="project-img">
                    <a href="assets/images/testimonials6.jpg" data-lightbox="gallery">
                        <img src="assets/images/testimonials6.jpg" alt="">
                    </a>
                </div>
            </div>
           
          
        </div>


</div>
<!-- project -->


<!-- footer  -->
<?php 
include_once 'includes/footer.php';
?>

<!-- footer  -->

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
<!-- Lightbox JavaScript -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/js/lightbox.min.js"></script>

<script src="assets/js/script.js"></script>

</body>

</html>